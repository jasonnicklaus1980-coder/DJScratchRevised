// Compile-time check of the VST2 struct layout for 32-bit targets (the MPC is 32-bit ARM, the x86 tests are 64-bit).
// Offsets/sizes are those of the public VST 2.4 ABI with 4-byte pointers and 8-byte-aligned doubles (ARM EABI).
//   make abi32     (syntax-only: needs no 32-bit libs beyond stdint.h/stddef.h)
#include <stddef.h>
#include "../src/vst2.h"
#if defined(__SIZEOF_POINTER__) && __SIZEOF_POINTER__ == 4
static_assert (sizeof (AEffect) == 144,                  "AEffect must be 144 bytes on 32-bit");
static_assert (offsetof (AEffect, dispatcher) == 4,      "dispatcher");
static_assert (offsetof (AEffect, numPrograms) == 20,    "numPrograms");
static_assert (offsetof (AEffect, flags) == 36,          "flags");
static_assert (offsetof (AEffect, ioRatio) == 60,        "ioRatio");
static_assert (offsetof (AEffect, object) == 64,         "object");
static_assert (offsetof (AEffect, uniqueID) == 72,       "uniqueID");
static_assert (offsetof (AEffect, processReplacing) == 80, "processReplacing");
static_assert (sizeof (VstEvent) == 32,                  "VstEvent");
static_assert (sizeof (VstMidiEvent) == 32,             "VstMidiEvent");
static_assert (sizeof (VstEvents) == 16,                 "VstEvents");
#ifdef __arm__
static_assert (sizeof (VstTimeInfo) == 88 && offsetof (VstTimeInfo, ppqPos) == 24 && offsetof (VstTimeInfo, tempo) == 32, "VstTimeInfo (EABI)");
#endif
#endif
int main() { return 0; }
