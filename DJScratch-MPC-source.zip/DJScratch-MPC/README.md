# DJ Scratch (MPC)

A live-input turntable front end for the MPC: scratch, stop, pitch and reverse whatever is coming into an MPC track, pad,
submix, the master or the Sampler's inserts, and let the MPC's own Sampler record the result. It never writes audio files. A native **MPC OS VST2 insert effect** for Gen1 devices (MPC X, Live /
Live II, One, Key 61, Force), built on the same toolchain, installer and skin pipeline as the SP1200 plugin.

    incoming audio > pitch shift (SHIFT mode) > history (10..120 s) > needle (the record) or loop > crossfade with the live
                   signal > transformer gate > fader > output > the MPC (e.g. the Sampler, recording from its INSERTS)

- **Transparent when idle**: bit-exact pass-through, zero latency.
- **Platter**: drag it or turn Q-Link 1; two-pole inertia, 4-point Hermite interpolation, a stopped record is silent.
- **Motor**: START/STOP with adjustable spin-up and wind-down (constant torque), BRAKE, 33/45, REVERSE; on live audio the
  record winds down, spins back up and slips (or catches up) back to live. Slipmat-style hand-off after a scratch.
- **Pitch**: +/-8/16/50 % fader, fine, spring-loaded bend, reset. SHIFT mode pitches the live input in real time and stays in
  time with it; VINYL mode is varispeed, like a record.
- **Sample source**: put a WAV from `DJ Scratch/Samples` on the platter instead of the live input (motor, cue, THRU).
- **Loop roll** keys (1/4, 1/8, 1/16, 1/32), **bar loops** (2, 4, 6, 8, 12, 20, 32 bars, following the MPC's time signature)
  and LOOP by note value (1/32..32 bars, triplets) at the MPC tempo, on the MPC's grid while it plays; **transformer**
  gate (rate, pattern, open) locked to the MPC beat; backspin, fader + chop, 17 presets.
- **MIDI controllers**: a default CC layout (record, jog wheels, pitch, crossfader, keys), MIDI LEARN for any controller
  (remembered in `DJ Scratch/midi-map.txt`), the pitch-bend wheel as a nudge; MIDI notes optional.
- Four screen pages (DECK, GROOVE, SAMPLE, SETUP): an original deck design with a record label that turns with the audio,
  a long pitch fader and an input meter. See `docs/skin-preview-*.png`.
- The only disk access (listing and loading WAVs for the SAMPLE source) is on a background thread; the audio thread never blocks.

How to use it: **`mpc/INSTALL.md`**.

## Build + install
    ./scripts/build_mpc.sh <mpc-ip>   # no GitHub: builds the ARM plugin (cross-compiler or Docker), checks it, packages, installs over SSH
    make abi32                        # 32-bit VST2 struct layout check (what the ARM MPC sees)
    make test                         # engine_test (ASan/UBSan) + host_test (VST2 interface and a scratch gesture through setParameter)
    python3 tools/make_skin.py docs   # regenerate the skin and previews (needs Pillow and `make native`)
    ./scripts/package.sh              # cross-compiles for ARM, verifies the ELF, makes dist/DJScratch-1.4.0-mpc-armv7.zip
    ./scripts/verify_arm.sh [file.so] # checks a .so against the SP1200 reference (ELF32 ARM, hard-float, libc/libm only)
./scripts/deploy.sh <mpc-ip>      # tar-over-ssh, runs install.sh
`package.sh` needs `arm-linux-gnueabihf-g++` (`apt install g++-arm-linux-gnueabihf`) or Docker (it uses `make docker`).
`make host_test` can also write a demo: `./build/native/host_test build/native/djscratch.so demo.wav`.

## Layout
    src/scratch/Scratch.h   the engine (ring buffer, platter model, states LIVE / GRAB / SPIN / RETURN, fader)
    src/djscratch.cpp       VST2 entry points, parameter table, presets, status readout, the I/O thread (sample loading)
    src/fileio.h            WAV reader (any rate, PCM/float, resampled on load), folder listing
    src/vst2.h              minimal VST2 ABI (no Steinberg SDK)
    tools/make_skin.py      TUI.json, Q-Links and PNGs for the MPC screen
    mpc/                    installer, uninstaller, plugin-list entry, skin, INSTALL.md
    test/                   engine_test.cpp, host_test.cpp

## Status: what is tested and what is not
Tested here, on x86: the DSP (engine_test, 137 checks, under AddressSanitizer and UBSan: scratching, the motor on live input
and on a sample, pitch shift and vinyl pitch, reverse, slipmat release, loops and the hand taking over a loop, 8-bar loops, loops too long for the history, loops on the MPC's grid, gate,
the history ring) and the plugin through a VST2 host harness (host_test, 235 checks: parameters, presets, brake / pitch / bend
controls, pitch modes, loop roll keys, MIDI notes on/off, the default CC layout, jog wheels (both encodings, endless),
the pitch-bend nudge, MIDI learn (including a jog wheel), CLEAR, learned controls surviving a restart, bar loop keys, a
real 32-bar loop on the 120 s history, 3/4 time from the host, bar loops and loop length from MIDI, the record turning with the motor and with the hand, the meter
read-out, host blocks up to 4096, loading a 48 kHz WAV at 44.1 kHz, and that playing writes no files), the I/O thread
under ThreadSanitizer, and the installer in a fake MPC root.

**Not tested on a device**: the ARM build (no ARM compiler where this was written), CPU load, how the MPC's touch drag maps to
the PLATTER value (set THROW to taste), whether the MPC redraws the plugin's read-outs (the turning record, the meter, the
status line, keys that spring back) when the plugin changes them, whether it reports tempo and beat position to an insert
(the plugin falls back to 120 BPM or the Tempo control), whether it sends MIDI notes to an insert, the `/media/az01-internal`
path from inside the MPC process (the plugin falls back to `/sdcard`), and the touch drag on the record (rebuilt from 84 px pieces like the pitch fader). The skin follows the SP1200 skin's proven rules; the big platter zone, the 3-piece pitch fader and the
3-piece meter are new.
