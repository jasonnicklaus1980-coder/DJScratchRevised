#!/usr/bin/env bash
# Check that a .so can load on a Gen1 MPC (32-bit ARM, hard-float, libc/libm only).
# Reference: GlueBus SP1200 2.0.0 sp1200.so = ELF32 ARM EABI5, armv7-a, Thumb-2, VFPv3-D16, hard-float, NEEDED libm+libc, glibc <= 2.29.
#   ./scripts/verify_arm.sh [file.so]       default: build/arm/djscratch.so
set -u
SO="${1:-build/arm/djscratch.so}"; RE="${READELF:-readelf}"; fail=0
[ -f "$SO" ] || { echo "no such file: $SO"; exit 2; }
command -v "$RE" >/dev/null || { echo "readelf not found"; exit 2; }
chk() { if eval "$2"; then echo "  ok    $1"; else echo "  FAIL  $1"; fail=1; fi; }
H=$("$RE" -h "$SO" 2>&1); A=$("$RE" -A "$SO" 2>&1); D=$("$RE" -d "$SO" 2>&1)
echo "$SO"
chk "ELF32"                      'grep -q "Class:.*ELF32" <<<"$H"'
chk "Machine: ARM"               'grep -q "Machine:.*ARM" <<<"$H"'
chk "EABI5, hard-float ABI"      'grep -q "Version5 EABI, hard-float ABI" <<<"$H"'
chk "ARMv7 (Tag_CPU_arch: v7)"   'grep -q "Tag_CPU_arch: v7" <<<"$A"'
chk "VFPv3-D16 or better"        'grep -Eq "Tag_FP_arch: (VFPv3|VFPv4|NEON)" <<<"$A"'
chk "VFP argument passing"       'grep -q "Tag_ABI_VFP_args: VFP registers" <<<"$A"'
chk "shared object (ET_DYN)"     'grep -q "Type:.*DYN" <<<"$H"'
need=$(sed -n 's/.*Shared library: \[\(.*\)\]/\1/p' <<<"$D" | sort | tr '\n' ' ')
chk "NEEDED only libc/libm (got: ${need:-none})" '[ -z "$(tr " " "\n" <<<"$need" | grep -v -E "^(libc\.so\.6|libm\.so\.6|)$")" ]'
maxg=$("$RE" -V "$SO" 2>/dev/null | grep -o 'GLIBC_[0-9.]*' | sort -uV | tail -1)
chk "glibc <= 2.34 (got: ${maxg:-none})" '[ -z "$maxg" ] || [ "$(printf "%s\n" "$maxg" GLIBC_2.34 | sort -V | tail -1)" = GLIBC_2.34 ]'
chk "exports VSTPluginMain or main" '"$RE" --dyn-syms -W "$SO" | grep -Eq " (VSTPluginMain|main)$"'
[ $fail = 0 ] && echo "PASS" || echo "FAILED"; exit $fail
