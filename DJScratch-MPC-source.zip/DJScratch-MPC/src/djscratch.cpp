// DJ Scratch - scratch the audio coming into an MPC track, submix or the master. A native MPC OS VST2 insert effect
// (Gen1, 32-bit ARM), built the same way as the SP1200 plugin: dependency-free VST2 core (src/vst2.h), one parameter
// table, a skin drawn by tools/make_skin.py, needs only libc/libm.
//
// The DSP is in src/scratch/Scratch.h. This file: parameters, presets (VST programs), host tempo, MIDI notes, the status
// readout, the I/O thread (SAMPLE source loading), entry points.
//
// Files live in "<drive>/DJ Scratch/": WAVs in Samples/ are the records for the SAMPLE source. The plugin never writes audio
// files: to sample the deck, put it in the MPC Sampler's inserts. <drive> is the MPC's internal drive (/media/az01-internal), else /sdcard; DJSCRATCH_DIR
// overrides the whole folder (tests). All disk access is on one background thread; the audio thread only hands buffers over.
#include "scratch/Scratch.h"
#include "fileio.h"
#include "vst2.h"
#include <pthread.h>
#include <unistd.h>
#include <atomic>
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <new>

#define DS_EXPORT extern "C" __attribute__((visibility("default")))

namespace
{
using namespace ds;

enum ParamId
{
    P_PLATTER, P_HOLD, P_AUTO, P_RELEASE, P_THROW, P_INERTIA,
    P_FADER, P_CHOP, P_BACKSPIN,
    P_RETURN, P_CATCH, P_SPINSPEED, P_SPINTIME, P_CHOPMS, P_CUTMS, P_OUTPUT, P_BYPASS,
    P_LOOP, P_LOOPLEN, P_BPM, P_TFORM, P_TRATE, P_TDUTY, P_TPAT,
    P_SOURCE, P_SAMPLE, P_PLAY, P_CUE, P_THRU, P_RESCAN,
    P_STARTT, P_STOPT, P_BRAKE, P_RPM, P_PITCH, P_PRANGE, P_PFINE, P_PRESET, P_BEND, P_REV,
    P_BUFLEN,
    P_ROLL4, P_ROLL8, P_ROLL16, P_ROLL32, P_NOTES, P_PMODE,
    P_MIDICC, P_LEARN, P_MIDICLR,
    P_BAR2, P_BAR4, P_BAR6, P_BAR8, P_BAR12, P_BAR20, P_BAR32,
    P_SPIN, P_INMETER,
    P_INFO,
    P_COUNT
};
enum Kind { K_FLOAT, K_CHOICE, K_BOOL, K_LOG, K_TEXT, K_METER };     // K_TEXT / K_METER: read-outs the plugin drives
enum Fmt { F_NUM, F_DB, F_SEC, F_MS, F_X, F_PLATTER, F_BPM, F_PCT, F_SAMPLE, F_PITCH, F_FINE, F_BEND, F_SPIN, F_METER };
constexpr int kMaxFiles = 128;
constexpr double kMaxSampleSec = 90.0;

const char* const kReturns[] { "Slip (jump)", "Catch up" };
const char* const kSources[] { "Live Input", "Sample" };
const char* const kRpm[] { "33", "45" };
const char* const kPModes[] { "Shift", "Vinyl" };     // Shift: live pitch changes instantly (SP-style); Vinyl: speed and position together
const char* const kRanges[] { "+/-8 %", "+/-16 %", "+/-50 %" };
const double kRangePct[] { 8.0, 16.0, 50.0 };
constexpr double kBendPct = 4.0;                        // a full nudge on BEND = +/-4 %, like a hand on the platter edge
const char* const kBufLen[] { "10 s", "20 s", "40 s", "60 s", "120 s" };
const double kBufSec[] { 10, 20, 40, 60, 120 };       // rounded up to a power of two of frames: 120 s holds ~3 minutes
// note values, in quarter-note beats (a quarter note = 1 beat)
const char* const kLoopNames[] { "1/32", "1/16T", "1/16", "1/8T", "1/8", "1/4T", "1/4", "1/2", "1 Bar",
                                 "2 Bars", "4 Bars", "6 Bars", "8 Bars", "12 Bars", "20 Bars", "32 Bars" };
constexpr int kNumLoops = 16;
const double kLoopBeats[] { 0.125, 1.0 / 6.0, 0.25, 1.0 / 3.0, 0.5, 2.0 / 3.0, 1.0, 2.0, 4.0 };   // up to 1 bar, in beats
const double kLoopBars[] { 0, 0, 0, 0, 0, 0, 0, 0, 1, 2, 4, 6, 8, 12, 20, 32 };            // bar lengths follow the time signature
const char* const kRateNames[] { "1/4", "1/8", "1/8T", "1/16", "1/16T", "1/32" };
const double kRateBeats[] { 1.0, 0.5, 1.0 / 3.0, 0.25, 1.0 / 6.0, 0.125 };
const char* const kPatNames[] { "Straight", "Offbeat", "Gallop", "Syncopated" };
const uint32_t kPatMask[] { 0xFFFFu, 0xAAAAu, 0xDDDDu, 0x4949u };     // 16 steps; Gallop = X.XX, Syncopated = X..X..X. (3+3+2)

struct ParamDef
{
    const char* key; const char* name; const char* unit; Kind kind; float lo, hi, step, def;
    const char* const* choices; int n; Fmt fmt;
};
#define CH(a) a, (int) (sizeof (a) / sizeof (a[0]))
ParamDef kParams[P_COUNT];
void initParams()
{
    auto f = [] (int i, const char* key, const char* name, const char* unit, Kind k, float lo, float hi, float step, float def, Fmt fm)
    { kParams[i] = { key, name, unit, k, lo, hi, step, def, nullptr, 0, fm }; };
    auto c = [] (int i, const char* key, const char* name, const char* const* ch, int n, int def)
    { kParams[i] = { key, name, "", K_CHOICE, 0, (float) (n - 1), 1, (float) def, ch, n, F_NUM }; };
    f (P_PLATTER, "platter", "Platter", "", K_FLOAT, 0, 1, 0, 0.5f, F_PLATTER);
    f (P_HOLD, "hold", "Hold", "", K_BOOL, 0, 1, 1, 0, F_NUM);
    f (P_AUTO, "auto", "Auto Grab", "", K_BOOL, 0, 1, 1, 1, F_NUM);
    f (P_RELEASE, "release", "Auto Release", "s", K_LOG, 0.1f, 4.f, 0, 0.4f, F_SEC);
    f (P_THROW, "throw", "Throw", "s", K_LOG, 0.25f, 4.f, 0, 1.f, F_SEC);
    f (P_INERTIA, "inertia", "Inertia", "ms", K_LOG, 3.f, 60.f, 0, 12.f, F_MS);
    f (P_FADER, "fader", "Fader Closed", "", K_BOOL, 0, 1, 1, 0, F_NUM);
    f (P_CHOP, "chop", "Chop", "", K_BOOL, 0, 1, 1, 0, F_NUM);
    f (P_BACKSPIN, "backspin", "Backspin", "", K_BOOL, 0, 1, 1, 0, F_NUM);
    c (P_RETURN, "return", "Return", CH (kReturns), 0);
    f (P_CATCH, "catch", "Catch-up Speed", "x", K_FLOAT, 1.5f, 8.f, 0.1f, 3.f, F_X);
    f (P_SPINSPEED, "spinspeed", "Spin Speed", "x", K_FLOAT, 2.f, 16.f, 0.5f, 8.f, F_X);
    f (P_SPINTIME, "spintime", "Spin Time", "s", K_LOG, 0.3f, 4.f, 0, 1.2f, F_SEC);
    f (P_CHOPMS, "chopms", "Chop Length", "ms", K_LOG, 10.f, 500.f, 0, 80.f, F_MS);
    f (P_CUTMS, "cutms", "Fader Time", "ms", K_LOG, 0.5f, 20.f, 0, 2.f, F_MS);
    f (P_OUTPUT, "output", "Output", "dB", K_FLOAT, -24, 12, 0.1f, 0, F_DB);
    f (P_BYPASS, "bypass", "Bypass", "", K_BOOL, 0, 1, 1, 0, F_NUM);
    f (P_LOOP, "loop", "Loop", "", K_BOOL, 0, 1, 1, 0, F_NUM);
    c (P_LOOPLEN, "looplen", "Loop Length", CH (kLoopNames), 4);
    f (P_BPM, "bpm", "Tempo", "BPM", K_FLOAT, 0, 240, 1, 0, F_BPM);
    f (P_TFORM, "tform", "Transformer", "", K_BOOL, 0, 1, 1, 0, F_NUM);
    c (P_TRATE, "trate", "Gate Rate", CH (kRateNames), 3);
    f (P_TDUTY, "tduty", "Gate Open", "%", K_FLOAT, 10, 100, 1, 50, F_PCT);
    c (P_TPAT, "tpat", "Gate Pattern", CH (kPatNames), 0);
    c (P_SOURCE, "source", "Source", CH (kSources), 0);
    f (P_SAMPLE, "sample", "Sample", "", K_FLOAT, 0, (float) (kMaxFiles - 1), 1, 0, F_SAMPLE);
    f (P_PLAY, "play", "Play", "", K_BOOL, 0, 1, 1, 1, F_NUM);
    f (P_CUE, "cue", "Cue", "", K_BOOL, 0, 1, 1, 0, F_NUM);
    f (P_THRU, "thru", "Input Thru", "", K_BOOL, 0, 1, 1, 1, F_NUM);
    f (P_RESCAN, "rescan", "Rescan", "", K_BOOL, 0, 1, 1, 0, F_NUM);
    f (P_STARTT, "startt", "Start Time", "s", K_LOG, 0.1f, 4.f, 0, 0.5f, F_SEC);
    f (P_STOPT, "stopt", "Stop Time", "s", K_LOG, 0.1f, 8.f, 0, 0.8f, F_SEC);
    f (P_BRAKE, "brake", "Brake", "", K_BOOL, 0, 1, 1, 0, F_NUM);
    c (P_RPM, "rpm", "Speed", CH (kRpm), 0);
    f (P_PITCH, "pitch", "Pitch", "%", K_FLOAT, -1, 1, 0, 0, F_PITCH);
    c (P_PRANGE, "prange", "Pitch Range", CH (kRanges), 0);
    f (P_PFINE, "pfine", "Fine Pitch", "%", K_FLOAT, -1, 1, 0.01f, 0, F_FINE);
    f (P_PRESET, "pitchreset", "Pitch Reset", "", K_BOOL, 0, 1, 1, 0, F_NUM);
    f (P_BEND, "bend", "Bend", "%", K_FLOAT, -1, 1, 0, 0, F_BEND);
    f (P_REV, "reverse", "Reverse", "", K_BOOL, 0, 1, 1, 0, F_NUM);
    c (P_BUFLEN, "buflen", "History", CH (kBufLen), 1);
    f (P_ROLL4, "roll4", "Loop 1/4", "", K_BOOL, 0, 1, 1, 0, F_NUM);
    f (P_ROLL8, "roll8", "Loop 1/8", "", K_BOOL, 0, 1, 1, 0, F_NUM);
    f (P_ROLL16, "roll16", "Loop 1/16", "", K_BOOL, 0, 1, 1, 0, F_NUM);
    f (P_ROLL32, "roll32", "Loop 1/32", "", K_BOOL, 0, 1, 1, 0, F_NUM);
    f (P_NOTES, "midinotes", "MIDI Notes", "", K_BOOL, 0, 1, 1, 0, F_NUM);
    c (P_PMODE, "pmode", "Pitch Mode", CH (kPModes), 0);
    f (P_MIDICC, "midicc", "MIDI Control", "", K_BOOL, 0, 1, 1, 1, F_NUM);
    f (P_LEARN, "midilearn", "MIDI Learn", "", K_BOOL, 0, 1, 1, 0, F_NUM);
    f (P_MIDICLR, "midiclear", "Clear MIDI", "", K_BOOL, 0, 1, 1, 0, F_NUM);
    f (P_BAR2, "bar2", "Loop 2 Bars", "", K_BOOL, 0, 1, 1, 0, F_NUM);
    f (P_BAR4, "bar4", "Loop 4 Bars", "", K_BOOL, 0, 1, 1, 0, F_NUM);
    f (P_BAR6, "bar6", "Loop 6 Bars", "", K_BOOL, 0, 1, 1, 0, F_NUM);
    f (P_BAR8, "bar8", "Loop 8 Bars", "", K_BOOL, 0, 1, 1, 0, F_NUM);
    f (P_BAR12, "bar12", "Loop 12 Bars", "", K_BOOL, 0, 1, 1, 0, F_NUM);
    f (P_BAR20, "bar20", "Loop 20 Bars", "", K_BOOL, 0, 1, 1, 0, F_NUM);
    f (P_BAR32, "bar32", "Loop 32 Bars", "", K_BOOL, 0, 1, 1, 0, F_NUM);
    kParams[P_SPIN] = { "spin", "Record Angle", "", K_METER, 0, 1, 0, 0, nullptr, 0, F_SPIN };
    kParams[P_INMETER] = { "inmeter", "Input Level", "", K_METER, 0, 1, 0, 0, nullptr, 0, F_METER };
    kParams[P_INFO] = { "info", "Status", "", K_TEXT, 0, 1000, 0, 0, nullptr, 0, F_NUM };
}
inline bool isTrigger (int i) { return i == P_CHOP || i == P_BACKSPIN || i == P_CUE || i == P_RESCAN || i == P_BRAKE || i == P_PRESET || i == P_MIDICLR; }

// ---------------------------------------------------------------- MIDI control (CC)
// The default layout (any channel). A learned assignment on the same channel + CC replaces it.
enum CcMode { CM_ABS = 1, CM_REL64 = 2, CM_REL2C = 3 };      // absolute; relative 64 = still; relative two's complement
constexpr float kJogStep = 1.f / 200.f;                      // one jog tick moves the platter control 1/200 (5 ms at Throw 1 s)
inline bool defaultCc (int cc, int& param, int& mode)
{
    mode = CM_ABS;
    switch (cc)
    {
        case 16: param = P_PLATTER; return true;                    // the record, from a knob or fader
        case 17: param = P_PLATTER; mode = CM_REL64; return true;   // the record, from a jog wheel (65 = forward, 63 = back)
        case 18: param = P_PLATTER; mode = CM_REL2C; return true;   // the record, from a jog wheel (1 = forward, 127 = back)
        case 19: param = P_PITCH; return true;                      // pitch fader (64 = 0 %)
        case 20: param = P_FADER; return true;                      // crossfader (all the way down = cut)
        case 21: param = P_PLAY; return true;                       // buttons from here on (127 = pressed)
        case 22: param = P_BRAKE; return true;
        case 23: param = P_BACKSPIN; return true;
        case 24: param = P_CHOP; return true;
        case 25: param = P_CUE; return true;
        case 26: param = P_REV; return true;
        case 27: param = P_ROLL4; return true;
        case 28: param = P_ROLL8; return true;
        case 29: param = P_ROLL16; return true;
        case 30: param = P_ROLL32; return true;
        case 31: param = P_TFORM; return true;
        case 32: param = P_BAR2; return true;                       // bar loops: press = on / off
        case 33: param = P_BAR4; return true;
        case 34: param = P_BAR6; return true;
        case 35: param = P_BAR8; return true;
        case 36: param = P_BAR12; return true;
        case 37: param = P_BAR20; return true;
        case 38: param = P_BAR32; return true;
        case 39: param = P_LOOPLEN; return true;                    // a knob picks the loop length (1/32 ... 32 bars)
        case 40: param = P_LOOP; return true;                       // LOOP on / off with that length
        case 64: param = P_HOLD; return true;                       // sustain pedal: hand on the record
        default: return false;
    }
}
inline bool isReadout (int i) { return kParams[i].kind == K_TEXT || kParams[i].kind == K_METER; }
// controls the presets leave alone (the performance state, the motor and pitch, and the SAMPLE source setup)
inline bool keptByPresets (int i)
{
    return i == P_PLATTER || i == P_HOLD || i == P_BYPASS || i == P_LOOP || i == P_BPM || isTrigger (i) || isReadout (i)
        || i >= P_SOURCE;                                   // the deck (motor, pitch), the sample and the sampler setup
}

float toPlain (const ParamDef& d, float norm)
{
    norm = clampf (norm, 0.f, 1.f);
    if (d.kind == K_BOOL) return norm >= 0.5f ? 1.f : 0.f;
    if (d.kind == K_CHOICE) return std::floor (norm * (float) (d.n - 1) + 0.5f);
    if (d.kind == K_LOG) return d.lo * std::pow (d.hi / d.lo, norm);
    float v = d.lo + norm * (d.hi - d.lo);
    if (d.step > 0.f) v = d.lo + std::floor ((v - d.lo) / d.step + 0.5f) * d.step;
    return clampf (v, d.lo, d.hi);
}
float toNorm (const ParamDef& d, float plain)
{
    if (d.kind == K_BOOL) return plain >= 0.5f ? 1.f : 0.f;
    if (d.kind == K_CHOICE) return d.n > 1 ? clampf (plain / (float) (d.n - 1), 0.f, 1.f) : 0.f;
    if (d.kind == K_LOG) return clampf (std::log (clampf (plain, d.lo, d.hi) / d.lo) / std::log (d.hi / d.lo), 0.f, 1.f);
    return clampf ((plain - d.lo) / (d.hi - d.lo), 0.f, 1.f);
}
void copyStr (void* dst, const char* src, size_t max = 24)
{
    if (dst == nullptr) return;
    std::strncpy ((char*) dst, src, max - 1);
    ((char*) dst)[max - 1] = 0;
}

// ---------------------------------------------------------------------------------------------- presets
struct Ov { int id; float v; };
struct Preset { const char* name; const Ov* ov; int n; };
#define PRESET(sym, ...) const Ov sym[] = { __VA_ARGS__ };
#define ENTRY(name, sym) { name, sym, (int) (sizeof (sym) / sizeof (sym[0])) }
PRESET (pClassic, { P_AUTO, 1 })
PRESET (pTight, { P_INERTIA, 5.f }, { P_THROW, 0.5f }, { P_RELEASE, 0.25f })
PRESET (pHeavy, { P_INERTIA, 35.f }, { P_THROW, 1.5f }, { P_RELEASE, 0.6f })
PRESET (pLong, { P_THROW, 3.f }, { P_RELEASE, 0.8f }, { P_INERTIA, 18.f })
PRESET (pSlip, { P_RETURN, 0 }, { P_RELEASE, 0.3f })
PRESET (pCatch, { P_RETURN, 1 }, { P_CATCH, 4.f }, { P_RELEASE, 0.35f })
PRESET (pManual, { P_AUTO, 0 })
PRESET (pTransform, { P_FADER, 1 }, { P_CHOPMS, 60.f }, { P_CUTMS, 1.f })
PRESET (pHardSpin, { P_SPINSPEED, 12.f }, { P_SPINTIME, 2.f })
PRESET (pSoftSpin, { P_SPINSPEED, 5.f }, { P_SPINTIME, 0.8f })
PRESET (pAutoT, { P_TFORM, 1 }, { P_TRATE, 3 }, { P_TPAT, 0 }, { P_TDUTY, 50 })
PRESET (pGallop, { P_TFORM, 1 }, { P_TRATE, 1 }, { P_TPAT, 2 }, { P_TDUTY, 70 })
PRESET (pSync, { P_TFORM, 1 }, { P_TRATE, 3 }, { P_TPAT, 3 }, { P_TDUTY, 60 })
PRESET (pTripCut, { P_TFORM, 1 }, { P_TRATE, 2 }, { P_TPAT, 1 }, { P_TDUTY, 80 })
PRESET (pLoop8, { P_LOOPLEN, 4 })
PRESET (pLoop16, { P_LOOPLEN, 2 })
PRESET (pLoop4, { P_LOOPLEN, 6 })
const Preset kPresets[] =
{
    ENTRY ("Classic Scratch", pClassic), ENTRY ("Tight Wrist", pTight), ENTRY ("Heavy Platter", pHeavy), ENTRY ("Long Throw", pLong),
    ENTRY ("Slip Mode", pSlip), ENTRY ("Catch Up", pCatch), ENTRY ("Manual Grab", pManual), ENTRY ("Hand Transformer", pTransform),
    ENTRY ("Hard Backspin", pHardSpin), ENTRY ("Soft Backspin", pSoftSpin),
    ENTRY ("Auto Transformer", pAutoT), ENTRY ("Gallop Gate", pGallop), ENTRY ("Syncopated Gate", pSync), ENTRY ("Triplet Cut", pTripCut),
    ENTRY ("Loop 1/8", pLoop8), ENTRY ("Loop 1/16", pLoop16), ENTRY ("Loop 1/4", pLoop4),
};
constexpr int kNumPresets = (int) (sizeof (kPresets) / sizeof (kPresets[0]));

// ---------------------------------------------------------------------------------------------- plugin
struct Text
{
    char buf[2][128] {}; std::atomic<int> live { 0 };
    const char* get() const { return buf[live.load()]; }
    bool publish (const char* s)
    {
        if (std::strcmp (get(), s) == 0) return false;
        const int idle = 1 - live.load(); std::snprintf (buf[idle], sizeof buf[idle], "%s", s); live.store (idle); return true;
    }
};

struct Plugin
{
    AEffect fx {};
    audioMasterCallback master = nullptr;
    std::atomic<float> v[P_COUNT], nv[P_COUNT];
    std::atomic<int> pending[P_COUNT];     // taps received on the trigger keys, consumed by the audio thread
    std::atomic<uint32_t> noteMask { 0 };  // MIDI notes held (pitch classes C..G# = loop lengths)
    std::atomic<int> noteLast { -1 };      // the loop length the latest held note selects
    std::atomic<int> tformDirty { 0 };     // a MIDI note flipped the transformer: tell the host
    int loopIdxActive = 4;
    double bpmUsed = 120.0; int tempoSrc = 2;   // 0 manual, 1 host, 2 default
    float sent[P_COUNT];
    int program = 0;
    float sr = 44100.f;
    Engine engine;
    Text info; int infoGen = 0;
    int displayCountdown = 0;

    // ---- files: the I/O thread owns the disk; these are its hand-over points
    std::atomic<float> srA { 44100.f };
    pthread_t ioThread {}; bool ioStarted = false; std::atomic<bool> ioQuit { false }; std::atomic<bool> dirsOk { false };
    char baseDir[256] {}, smpDir[320] {};
    // the file list: written by the I/O thread only, read by the host thread (parameter display) under a sequence lock
    struct Files { std::atomic<uint32_t> seq { 0 }; int count = 0; char rel[kMaxFiles][128]; char shown[kMaxFiles][64]; } files;
    std::atomic<int> rescanReq { 1 };
    char scanTmp[kMaxFiles][128];                                // I/O thread scratch space for a folder listing
    // the record on the platter (SAMPLE source): I/O thread -> next -> audio thread (cur) -> retired -> I/O thread frees it
    std::atomic<dsio::Sample*> next { nullptr }, retired { nullptr };
    dsio::Sample* cur = nullptr;
    char loadedRel[128] {}; float loadedSr = 0; char failedRel[128] {};
    static constexpr int kChunk = 1024;                            // process() works in chunks of at most this many frames
    // the deck
    // LOOP ROLL keys (DECK page): one at a time, like beat-repeat buttons. Index into kLoopNames: 1/4, 1/8, 1/16, 1/32.
    // BAR LOOP keys (GROOVE page) join them: 2, 4, 6, 8, 12, 20, 32 bars. One loop key at a time across all eleven.
    static constexpr int kNumRoll = 11;
    static constexpr int kRollParam[kNumRoll] { P_ROLL4, P_ROLL8, P_ROLL16, P_ROLL32, P_BAR2, P_BAR4, P_BAR6, P_BAR8, P_BAR12, P_BAR20, P_BAR32 };
    static constexpr int kRollLoop[kNumRoll] { 6, 4, 2, 0, 9, 10, 11, 12, 13, 14, 15 };
    bool rollWas[kNumRoll] {}; int rollActive = -1;
    double barBeats = 4.0;                                      // beats in a bar: the MPC's time signature, else 4/4
    bool braking = false; float lastBend = 0; int bendIdle = 0; double angle = 0; int visualCountdown = 0;
    // the history buffer (HISTORY): the I/O thread allocates a new ring, the audio thread swaps it in
    std::atomic<float*> nextRing { nullptr }, retiredRing { nullptr }; std::atomic<uint32_t> nextRingFrames { 0 }, ringFramesNow { 0 };
    Text ioMsg; std::atomic<int> ioMsgGen { 0 }; int seenMsgGen = 0; int msgLeft = 0;

    // ---- MIDI control: learned assignments by channel + CC (audio thread), button/knob state, MIDI learn
    int16_t ccParam[16][128]; uint8_t ccMode[16][128];
    uint8_t ccLast[16][128] {}; uint8_t ccSeen[16][128] {};
    std::atomic<uint8_t> ccDirty[P_COUNT];                       // the screen needs this parameter's new value
    bool jogDriven = false; bool midiBendHeld = false;
    std::atomic<int> learnTarget { -1 };                        // the control touched on screen while MIDI LEARN is on
    int learnCh = -1, learnCc = -1, learnN = 0, learnVals[4] {}, learnAge = 0;
    Text midiMsg; std::atomic<int> midiMsgGen { 0 }; int seenMidiGen = 0; bool msgFromMidi = false;
    // learned assignments are kept in DJ Scratch/midi-map.txt: published to the I/O thread under a sequence lock, and loaded
    // by it at start (mapIn + mapPending)
    struct MapShare { std::atomic<uint32_t> seq { 0 }; int16_t param[16][128]; uint8_t mode[16][128]; } mapShare;
    int16_t mapInParam[16][128]; uint8_t mapInMode[16][128]; std::atomic<int> mapPending { 0 };
    uint32_t mapSavedSeq = 0;                                   // I/O thread

    Plugin()
    {
        for (int i = 0; i < P_COUNT; ++i) { setPlain (i, kParams[i].def); sent[i] = 1e9f; pending[i].store (0); ccDirty[i].store (0); }
        for (int c = 0; c < 16; ++c) for (int k = 0; k < 128; ++k) { ccParam[c][k] = -1; ccMode[c][k] = 0; }
        engine.setRingSeconds (kBufSec[clampi ((int) kParams[P_BUFLEN].def, 0, 4)]);
        engine.prepare (sr);
        ringFramesNow.store (engine.ringSize());
    }
    // host thread: (re)prepare the engine for a new sample rate or history length
    void prepareEngine (float rate)
    {
        engine.setRingSeconds (kBufSec[clampi ((int) get (P_BUFLEN), 0, 4)]);
        engine.prepare (rate);
        ringFramesNow.store (engine.ringSize());
    }
    ~Plugin()
    {
        stopIO();
        dsio::freeSample (next.exchange (nullptr)); dsio::freeSample (retired.exchange (nullptr)); dsio::freeSample (cur); cur = nullptr;
        std::free (nextRing.exchange (nullptr)); std::free (retiredRing.exchange (nullptr));
    }
    void setPlain (int i, float plain) { v[i].store (plain); nv[i].store (toNorm (kParams[i], plain)); }
    static bool learnable (int i) { return ! isReadout (i) && i != P_LEARN && i != P_MIDICLR && i != P_MIDICC; }
    bool learnArmed() const { return get (P_LEARN) > 0.5f; }
    void setNorm (int i, float norm)
    {
        if (isReadout (i)) return;
        norm = clampf (norm, 0.f, 1.f);
        // MIDI LEARN: the first control touched on screen becomes the target; it keeps its value (the screen is put back)
        if (learnArmed() && learnTarget.load() < 0 && learnable (i) && std::fabs (norm - nv[i].load()) > 1e-6f)
        {
            learnTarget.store (i); ccDirty[i].store (1);
            return;
        }
        if (i == P_PLATTER) jogDriven = false;                                       // the screen / a Q-Link moves it now
        setNormRaw (i, norm);
    }
    void setNormRaw (int i, float norm)
    {
        const ParamDef& d = kParams[i];
        norm = clampf (norm, 0.f, 1.f);
        nv[i].store (norm); v[i].store (toPlain (d, norm));
        if (isTrigger (i) && norm >= 0.5f) pending[i].fetch_add (1);       // a tap
    }
    float get (int i) const { return v[i].load(); }
    void applyPreset (int i)
    {
        if (i < 0 || i >= kNumPresets) return;
        program = i;
        for (int p = 0; p < P_COUNT; ++p)
            if (! keptByPresets (p)) setPlain (p, kParams[p].def);
        for (int k = 0; k < kPresets[i].n; ++k) setPlain (kPresets[i].ov[k].id, kPresets[i].ov[k].v);
    }
    void notifyHostAll()
    {
        if (master == nullptr) return;
        for (int i = 0; i < P_COUNT; ++i) if (! isReadout (i)) master (&fx, audioMasterAutomate, i, 0, nullptr, nv[i].load());
        master (&fx, audioMasterUpdateDisplay, 0, 0, nullptr, 0.f);
    }
    double pitchPct() const
    {
        return (double) get (P_PITCH) * kRangePct[clampi ((int) get (P_PRANGE), 0, 2)] + (double) get (P_PFINE) + (double) get (P_BEND) * kBendPct;
    }
    double speedNow() const { return (get (P_RPM) > 0.5f ? 1.35 : 1.0) * (1.0 + pitchPct() / 100.0); }
    // SHIFT (live source): the pitch shifter changes the input's pitch in real time; the motor only starts, stops, reverses.
    // VINYL, or the SAMPLE source: pitch is the record's speed.
    bool shiftMode() const { return get (P_PMODE) < 0.5f && get (P_SOURCE) < 0.5f; }
    void applySpeed (Settings& s) const
    {
        if (shiftMode()) { s.speed = 1.0; s.shiftRatio = speedNow(); }
        else { s.speed = speedNow(); s.shiftRatio = 1.0; }
    }
    Settings settings() const
    {
        Settings s;
        s.platter = get (P_PLATTER); s.hold = get (P_HOLD) > 0.5f; s.autoGrab = get (P_AUTO) > 0.5f; s.releaseSec = get (P_RELEASE);
        s.throwSec = get (P_THROW); s.inertiaMs = get (P_INERTIA); s.faderClosed = get (P_FADER) > 0.5f; s.chopMs = get (P_CHOPMS);
        s.cutMs = get (P_CUTMS); s.spinSpeed = get (P_SPINSPEED); s.spinSec = get (P_SPINTIME); s.returnMode = (int) get (P_RETURN);
        s.catchSpeed = get (P_CATCH); s.outDb = get (P_OUTPUT); s.bypass = get (P_BYPASS) > 0.5f;
        s.deck = get (P_SOURCE) > 0.5f; s.motorOn = get (P_PLAY) > 0.5f; s.thru = get (P_THRU) > 0.5f;
        applySpeed (s); s.reverse = get (P_REV) > 0.5f;
        s.startSec = get (P_STARTT); s.stopSec = braking ? 0.12f : get (P_STOPT);
        return s;
    }


    // ================================================================ I/O thread
    void say (const char* fmt, const char* a, double x = 0)
    {
        char b[128]; std::snprintf (b, sizeof b, fmt, a, x);
        ioMsg.publish (b); ioMsgGen.fetch_add (1);
    }
    bool setupDirs()
    {
        const char* env = std::getenv ("DJSCRATCH_DIR");
        const char* cands[] { env, "/media/az01-internal/DJ Scratch", "/sdcard/DJ Scratch" };
        for (const char* c : cands)
        {
            if (c == nullptr || c[0] == 0) continue;
            char parent[256]; std::snprintf (parent, sizeof parent, "%s", c);
            char* sl = std::strrchr (parent, '/'); if (sl != nullptr && sl != parent) *sl = 0;
            if (c != env && ! dsio::isDir (parent)) continue;                    // that drive isn't there
            std::snprintf (baseDir, sizeof baseDir, "%s", c);
            std::snprintf (smpDir, sizeof smpDir, "%s/Samples", c);
            if (dsio::makeDirs (smpDir)) return true;
        }
        baseDir[0] = 0;
        return false;
    }
    void scan()
    {
        int n = 0;
        files.seq.fetch_add (1);                             // odd: the list is being rewritten
        const int k = dsio::listWavs (smpDir, scanTmp, kMaxFiles);
        for (int j = 0; j < k; ++j, ++n)
        {
            std::snprintf (files.rel[n], sizeof files.rel[n], "Samples/%s", scanTmp[j]);
            dsio::baseName (scanTmp[j], files.shown[n], sizeof files.shown[n]);
        }
        files.count = n;
        files.seq.fetch_add (1);
        failedRel[0] = 0;                                    // a rescan retries a file that failed to load
    }
    void serviceLoader()
    {
        const int n = files.count;
        if (n == 0) return;
        const int idx = PluginClamp ((int) get (P_SAMPLE), 0, kMaxFiles - 1);
        if (idx >= n) return;
        const float sr = srA.load();
        if (std::strcmp (files.rel[idx], loadedRel) == 0 && loadedSr == sr) return;
        if (std::strcmp (files.rel[idx], failedRel) == 0) return;
        if (next.load() != nullptr || retired.load() != nullptr) return;          // the audio thread hasn't taken the last one yet
        char path[640]; std::snprintf (path, sizeof path, "%s/%s", baseDir, files.rel[idx]);
        char err[64] = "";
        dsio::Sample* smp = dsio::loadWav (path, sr, kMaxSampleSec, err, sizeof err);
        if (smp == nullptr)
        {
            std::snprintf (failedRel, sizeof failedRel, "%s", files.rel[idx]);
            char nm[64], m[128]; dsio::baseName (files.rel[idx], nm, sizeof nm); std::snprintf (m, sizeof m, "%s: %s", nm, err);
            say ("CAN'T LOAD %s", m); return;
        }
        std::snprintf (loadedRel, sizeof loadedRel, "%s", files.rel[idx]); loadedSr = sr;
        next.store (smp);
        if (smp->truncated) say ("LOADED %s (first 90 s)", smp->name);
        else say ("LOADED %s  %.1f s", smp->name, (double) smp->len / sr);
    }
    // HISTORY changed (or the rate did): make a ring of the new size; the audio thread swaps it in
    void serviceRing()
    {
        const float rate = srA.load();
        const uint32_t want = Engine::ringFramesFor (rate, kBufSec[clampi ((int) get (P_BUFLEN), 0, 4)]);
        if (want == ringFramesNow.load() || nextRing.load() != nullptr || retiredRing.load() != nullptr) return;
        float* m = (float*) std::calloc ((size_t) want * 2, sizeof (float));
        if (m == nullptr) { say ("HISTORY: NOT ENOUGH MEMORY%s", ""); return; }
        nextRingFrames.store (want);
        nextRing.store (m);
    }
    // MIDI learn assignments: DJ Scratch/midi-map.txt, one "channel cc control mode" per line (control by its key, so the
    // file survives new versions that renumber the controls)
    void loadMidiMap()
    {
        char path[320]; std::snprintf (path, sizeof path, "%s/midi-map.txt", baseDir);
        FILE* f = std::fopen (path, "r");
        if (f == nullptr) return;
        for (int c = 0; c < 16; ++c) for (int k = 0; k < 128; ++k) { mapInParam[c][k] = -1; mapInMode[c][k] = 0; }
        char line[160]; int n = 0;
        while (std::fgets (line, sizeof line, f) != nullptr)
        {
            if (line[0] == '#') continue;
            // "ch cc key mode", parsed by hand (no scanf: keeps the plugin on the MPC's older C library)
            const char* q = line;
            auto num = [&q] (int& out) { while (*q == ' ' || *q == '\t') ++q; if (*q < '0' || *q > '9') return false;
                                         out = 0; while (*q >= '0' && *q <= '9') out = out * 10 + (*q++ - '0'); return true; };
            int ch = 0, cc = 0, mode = 0; char key[32] = "";
            if (! num (ch) || ! num (cc)) continue;
            while (*q == ' ' || *q == '\t') ++q;
            int kl = 0; while (*q > ' ' && kl < 31) key[kl++] = *q++;
            key[kl] = 0;
            if (kl == 0 || ! num (mode)) continue;
            if (ch < 1 || ch > 16 || cc < 0 || cc > 127 || mode < CM_ABS || mode > CM_REL2C) continue;
            for (int i = 0; i < P_COUNT; ++i)
                if (learnable (i) && std::strcmp (kParams[i].key, key) == 0) { mapInParam[ch - 1][cc] = (int16_t) i; mapInMode[ch - 1][cc] = (uint8_t) mode; ++n; break; }
        }
        std::fclose (f);
        if (n > 0) mapPending.store (1);
    }
    void saveMidiMap()
    {
        const uint32_t a = mapShare.seq.load (std::memory_order_acquire);
        if (a == mapSavedSeq || (a & 1u) != 0) return;
        static_assert (sizeof (mapInParam) == sizeof (mapShare.param), "map size");
        int16_t prm[16][128]; uint8_t mde[16][128];
        std::memcpy (prm, mapShare.param, sizeof prm); std::memcpy (mde, mapShare.mode, sizeof mde);
        std::atomic_thread_fence (std::memory_order_acquire);
        if (mapShare.seq.load (std::memory_order_relaxed) != a) return;           // changed while copying: next time
        mapSavedSeq = a;
        char path[320], tmp[330];
        std::snprintf (path, sizeof path, "%s/midi-map.txt", baseDir); std::snprintf (tmp, sizeof tmp, "%s.tmp", path);
        FILE* f = std::fopen (tmp, "w");
        if (f == nullptr) { say ("MIDI: CAN'T SAVE LEARNED CONTROLS IN %s", baseDir); return; }
        std::fprintf (f, "# DJ Scratch MIDI learn: channel cc control mode (1 = absolute, 2 = jog 64, 3 = jog 1/127)\n");
        for (int c = 0; c < 16; ++c) for (int k = 0; k < 128; ++k)
            if (prm[c][k] >= 0 && prm[c][k] < P_COUNT) std::fprintf (f, "%d %d %s %d\n", c + 1, k, kParams[prm[c][k]].key, mde[c][k]);
        const bool ok = std::fclose (f) == 0;
        if (ok) std::rename (tmp, path); else std::remove (tmp);
    }
    void ioLoop()
    {
        if (setupDirs()) { dirsOk.store (true); loadMidiMap(); }
        int scanLeftMs = 0;
        while (! ioQuit.load())
        {
            dsio::freeSample (retired.exchange (nullptr));
            std::free (retiredRing.exchange (nullptr));
            serviceRing();                                       // the scratch history doesn't need the folder
            if (dirsOk.load())
            {
                saveMidiMap();
                const bool deck = get (P_SOURCE) > 0.5f;
                if (rescanReq.exchange (0) != 0 || (deck && scanLeftMs <= 0)) { scan(); scanLeftMs = 2000; }
                if (deck) serviceLoader();
            }
            const int ms = 20;
            usleep ((useconds_t) ms * 1000);
            scanLeftMs -= ms;
        }
    }
    static void* ioEntry (void* self) { static_cast<Plugin*> (self)->ioLoop(); return nullptr; }
    void startIO() { if (pthread_create (&ioThread, nullptr, &Plugin::ioEntry, this) == 0) ioStarted = true; }
    void stopIO() { if (! ioStarted) return; ioQuit.store (true); pthread_join (ioThread, nullptr); ioStarted = false; }
    bool ioOk() const { return ioStarted && dirsOk.load(); }
    // host thread: the name shown for list entry i
    bool fileShown (int i, char* out, size_t max, int* count)
    {
        for (int tries = 0; tries < 50; ++tries)
        {
            const uint32_t a = files.seq.load (std::memory_order_acquire);
            if (a & 1u) { usleep (200); continue; }
            const int n = files.count;
            if (i >= 0 && i < n) std::snprintf (out, max, "%s", files.shown[i]); else out[0] = 0;
            std::atomic_thread_fence (std::memory_order_acquire);
            if (files.seq.load (std::memory_order_relaxed) == a) { *count = n; return i >= 0 && i < n; }
        }
        out[0] = 0; *count = 0; return false;
    }
    static int PluginClamp (int x, int lo, int hi) { return x < lo ? lo : (x > hi ? hi : x); }

    // ---------------------------------------------------------------- MIDI control (CC, pitch bend, MIDI learn)
    void setFromMidi (int i, float norm) { setNormRaw (i, norm); ccDirty[i].store (1); }
    void midiCc (int ch, int cc, int val)
    {
        if (learnArmed() && learnTarget.load() >= 0)                               // learning: the first CC moved goes to the target
        {
            if (learnN == 0) { learnCh = ch; learnCc = cc; learnAge = 0; }
            if (ch == learnCh && cc == learnCc && learnN < 4) learnVals[learnN++] = val;
            return;
        }
        if (learnArmed() || get (P_MIDICC) < 0.5f) return;
        int param = ccParam[ch][cc], mode = ccMode[ch][cc];
        if (param < 0 && ! defaultCc (cc, param, mode)) return;
        const int last = ccSeen[ch][cc] ? ccLast[ch][cc] : -1;
        ccSeen[ch][cc] = 1; ccLast[ch][cc] = (uint8_t) val;
        applyCc (param, mode, val, last);
    }
    void applyCc (int p, int mode, int val, int last)
    {
        const ParamDef& d = kParams[p];
        if (p == P_PLATTER)                                                         // the record: always moved by how far you turn
        {
            float delta;
            if (mode == CM_REL64) delta = (float) (val - 64) * kJogStep;
            else if (mode == CM_REL2C) delta = (float) (val < 64 ? val : val - 128) * kJogStep;
            else { if (last < 0) return; delta = (float) (val - last) / 127.f; }   // a knob: its movement, so it never jumps
            setFromMidi (P_PLATTER, clampf (get (P_PLATTER) + delta, 0.f, 1.f));
            jogDriven = true;
            return;
        }
        if (p == P_PITCH) { setFromMidi (p, val <= 64 ? (float) val / 128.f : 0.5f + (float) (val - 64) / 126.f); return; }   // 64 = 0 %
        if (p == P_FADER) { setFromMidi (p, val <= 8 ? 1.f : 0.f); return; }       // a crossfader: all the way down = cut
        if (d.kind == K_BOOL)
        {
            const bool on = val >= 64, wasOn = last >= 64;
            if (isTrigger (p)) { if (on && ! wasOn) setFromMidi (p, 1.f); return; }
            if (p == P_HOLD || p == P_ROLL4 || p == P_ROLL8 || p == P_ROLL16 || p == P_ROLL32) { setFromMidi (p, on ? 1.f : 0.f); return; }   // held
            if (on && ! wasOn) setFromMidi (p, get (p) > 0.5f ? 0.f : 1.f);        // press = toggle
            return;
        }
        setFromMidi (p, (float) val / 127.f);                                       // knobs and choices
    }
    void midiBend (int v14)                                                         // the pitch-bend wheel nudges (BEND), held as long as you hold it
    {
        if (learnArmed() || get (P_MIDICC) < 0.5f) return;
        const float b = clampf ((float) (v14 - 8192) / 8191.f, -1.f, 1.f);
        midiBendHeld = v14 != 8192;
        setFromMidi (P_BEND, (b + 1.f) * 0.5f);
    }
    void sayMidi (const char* text) { midiMsg.publish (text); midiMsgGen.fetch_add (1); }
    void publishMap()
    {
        mapShare.seq.fetch_add (1);
        std::memcpy (mapShare.param, ccParam, sizeof ccParam); std::memcpy (mapShare.mode, ccMode, sizeof ccMode);
        mapShare.seq.fetch_add (1);
    }
    void finishLearn()
    {
        const int t = learnTarget.load();
        int mode = CM_ABS;
        if (t == P_PLATTER && learnN >= 2)                                          // a jog wheel sends small steps around 0 or 64
        {
            bool rel2c = true, rel64 = true, repeat = false;
            for (int k = 0; k < learnN; ++k)
            {
                const int v0 = learnVals[k];
                if (! ((v0 >= 1 && v0 <= 15) || v0 >= 113)) rel2c = false;
                if (v0 < 56 || v0 > 72 || v0 == 64) rel64 = false;
                if (k > 0 && v0 == learnVals[k - 1]) repeat = true;
            }
            if (rel2c) mode = CM_REL2C; else if (rel64 && repeat) mode = CM_REL64;
        }
        ccParam[learnCh][learnCc] = (int16_t) t; ccMode[learnCh][learnCc] = (uint8_t) mode; ccSeen[learnCh][learnCc] = 0;
        publishMap();
        char m[96];
        std::snprintf (m, sizeof m, "LEARNED CC %d (ch %d) -> %s%s", learnCc, learnCh + 1, kParams[t].name,
                       mode == CM_REL2C || mode == CM_REL64 ? " (jog wheel)" : "");
        sayMidi (m);
        learnTarget.store (-1); learnN = 0;
        send (P_LEARN, 0.f, 0.f);
    }
    // audio thread, every block: learn timing, CLEAR, a map loaded from disk, endless jog, the screen catching up
    void midiControl (int n)
    {
        if (mapPending.load() != 0)
        {
            std::memcpy (ccParam, mapInParam, sizeof ccParam); std::memcpy (ccMode, mapInMode, sizeof ccMode);
            mapPending.store (0);
        }
        if (learnArmed())
        {
            if (learnN > 0 && (learnAge += n) > (int) (0.25f * sr)) finishLearn();   // a quarter second of the knob or button
        }
        else if (learnTarget.load() >= 0 || learnN > 0) { learnTarget.store (-1); learnN = 0; }   // LEARN turned off: cancelled
        if (pending[P_MIDICLR].exchange (0) > 0)
        {
            for (int c = 0; c < 16; ++c) for (int k = 0; k < 128; ++k) { ccParam[c][k] = -1; ccMode[c][k] = 0; }
            publishMap();
            sayMidi ("MIDI: LEARNED CONTROLS CLEARED (DEFAULT LAYOUT ACTIVE)");
            send (P_MIDICLR, 0.f, 0.f);
        }
        // an endless jog wheel keeps turning: re-centre the platter control under the hand without moving the needle
        const float pp = get (P_PLATTER);
        if (jogDriven && engine.state() == Engine::GRAB && (pp < 0.2f || pp > 0.8f))
        {
            engine.shiftPlatter (pp, 0.5f);
            setPlain (P_PLATTER, 0.5f); ccDirty[P_PLATTER].store (1);
        }
        for (int i = 0; i < P_COUNT; ++i)
            if (ccDirty[i].exchange (0) != 0) { sent[i] = get (i); if (master != nullptr) master (&fx, audioMasterAutomate, i, 0, nullptr, nv[i].load()); }
    }

    // ---------------------------------------------------------------- MIDI notes (if the host sends them to an insert)
    // C..G# hold a loop of the matching length (see kLoopNames), A = backspin, A# = chop, B = transformer on/off.
    void midiNote (int note, bool on)
    {
        const int pc = note % 12;
        if (on)
        {
            if (pc < 9) { noteMask.fetch_or (1u << pc); noteLast.store (pc); }
            else if (pc == 9) pending[P_BACKSPIN].fetch_add (1);
            else if (pc == 10) pending[P_CHOP].fetch_add (1);
            else { setPlain (P_TFORM, get (P_TFORM) > 0.5f ? 0.f : 1.f); tformDirty.store (1); }
        }
        else if (pc < 9)
        {
            const uint32_t m = noteMask.fetch_and (~(1u << pc)) & ~(1u << pc);
            if (noteLast.load() == pc) { int k = -1; for (int b = 8; b >= 0; --b) if (m & (1u << b)) { k = b; break; } noteLast.store (k); }
        }
    }
    void midiEvents (const VstEvents* ev)
    {
        if (ev == nullptr) return;
        int n = ev->numEvents; if (n > 256) n = 256;
        const VstEvent* const* arr = &ev->events[0];
        for (int i = 0; i < n; ++i)
        {
            const VstEvent* e = arr[i];
            if (e == nullptr || e->type != kVstMidiType) continue;
            const VstMidiEvent* m = reinterpret_cast<const VstMidiEvent*> (e);
            const int st = m->midiData[0] & 0xF0, ch = m->midiData[0] & 0x0F, d1 = m->midiData[1] & 0x7F, d2 = m->midiData[2] & 0x7F;
            const bool notes = get (P_NOTES) > 0.5f;                   // MIDI NOTES off: pads and sequences don't play the deck
            if (st == 0x90 && d2 > 0) { if (notes) midiNote (d1, true); }
            else if (st == 0x80 || st == 0x90) { if (notes) midiNote (d1, false); }
            else if (st == 0xB0 && (d1 == 123 || d1 == 120)) { noteMask.store (0); noteLast.store (-1); }     // all notes off
            else if (st == 0xB0) midiCc (ch, d1, d2);
            else if (st == 0xE0) midiBend (d1 | (d2 << 7));
        }
    }
    // tempo and transport from the host; the BPM control overrides it
    void readHostTime (Settings& s)
    {
        double hostTempo = 0; s.ppqValid = false; s.ppq = 0;
        if (master != nullptr)
        {
            const intptr_t r = master (&fx, audioMasterGetTime, 0, kVstTempoValid | kVstPpqPosValid | kVstTimeSigValid, nullptr, 0.f);
            const VstTimeInfo* ti = reinterpret_cast<const VstTimeInfo*> (r);
            if (ti != nullptr)
            {
                if ((ti->flags & kVstTempoValid) != 0 && ti->tempo >= 20.0 && ti->tempo <= 400.0) hostTempo = ti->tempo;
                if ((ti->flags & kVstTimeSigValid) != 0 && ti->timeSigNumerator >= 1 && ti->timeSigNumerator <= 32
                    && (ti->timeSigDenominator == 2 || ti->timeSigDenominator == 4 || ti->timeSigDenominator == 8 || ti->timeSigDenominator == 16))
                    barBeats = (double) ti->timeSigNumerator * 4.0 / (double) ti->timeSigDenominator;
                else barBeats = 4.0;
                if ((ti->flags & kVstPpqPosValid) != 0 && (ti->flags & kVstTransportPlaying) != 0 && ti->ppqPos >= 0.0) { s.ppqValid = true; s.ppq = ti->ppqPos; }
            }
        }
        const double manual = get (P_BPM);
        if (manual >= 1.0) { bpmUsed = manual; tempoSrc = 0; s.ppqValid = false; }          // a typed tempo is not the host's grid
        else if (hostTempo > 0) { bpmUsed = hostTempo; tempoSrc = 1; }
        else { bpmUsed = 120.0; tempoSrc = 2; }
        s.bpm = bpmUsed;
    }

    // ---------------------------------------------------------------- audio thread -> host
    void send (int i, float plain, float thr)
    {
        setPlain (i, plain);
        if (std::fabs (plain - sent[i]) < thr) return;
        sent[i] = plain;
        if (master != nullptr) master (&fx, audioMasterAutomate, i, 0, nullptr, nv[i].load());
    }
    void updateDisplay()
    {
        char t[128], tail[64] = "";
        const float vel = engine.velocity();
        char tempo[32]; std::snprintf (tempo, sizeof tempo, "%.0f BPM%s", bpmUsed, tempoSrc == 1 ? " host" : (tempoSrc == 2 ? " (default)" : ""));
        if (get (P_TFORM) > 0.5f && get (P_BYPASS) < 0.5f)
            std::snprintf (tail, sizeof tail, "  |  GATE %s %s", kRateNames[clampi ((int) get (P_TRATE), 0, 5)], kPatNames[clampi ((int) get (P_TPAT), 0, 3)]);
        const bool deck = engine.deckMode();
        const char* nm = (deck && cur != nullptr) ? cur->name : "";
        switch (engine.state())
        {
            case Engine::GRAB:
                if (deck) std::snprintf (t, sizeof t, "SCRATCH  %+.1fx  %s  %.2f s%s", (double) vel, nm, (double) engine.deckPosSec(), tail);
                else std::snprintf (t, sizeof t, "SCRATCH  %+.1fx   %.2f s back%s", (double) vel, (double) engine.behindSec(), tail);
                break;
            case Engine::SPIN: std::snprintf (t, sizeof t, "BACKSPIN  %+.1fx%s", (double) vel, tail); break;
            case Engine::PLAY:
            {
                const float ms = engine.motorSpeed();
                if (std::fabs (ms) < 0.005f) std::snprintf (t, sizeof t, "STOPPED  %.1f s behind live%s", (double) engine.behindSec(), tail);
                else if (ms < 0.f) std::snprintf (t, sizeof t, "REVERSE  %.1fx  %.1f s back%s", (double) ms, (double) engine.behindSec(), tail);
                else if (get (P_PLAY) < 0.5f) std::snprintf (t, sizeof t, "STOPPING  %.2fx%s", (double) ms, tail);
                else std::snprintf (t, sizeof t, "PITCH %+.1f %%  %.2f s behind%s", pitchPct() + (get (P_RPM) > 0.5f ? 35.0 : 0.0), (double) engine.behindSec(), tail);
                break;
            }
            case Engine::RETURN:
                if (deck) std::snprintf (t, sizeof t, "RELEASE  %+.1fx  %s%s", (double) vel, nm, tail);
                else std::snprintf (t, sizeof t, "CATCH UP  %.2f s to live%s", (double) engine.behindSec(), tail);
                break;
            case Engine::LOOP: std::snprintf (t, sizeof t, "LOOP %s  %.2f s  %s%s", kLoopNames[clampi (loopIdxActive, 0, kNumLoops - 1)], (double) engine.loopSec(), tempo, tail); break;
            default:
                if (get (P_BYPASS) > 0.5f) std::snprintf (t, sizeof t, "BYPASS");
                else if (engine.loopFailedTooLong())
                    std::snprintf (t, sizeof t, "LOOP %s needs %.0f s: raise History (SAMPLE page)", kLoopNames[clampi (loopIdxActive, 0, kNumLoops - 1)], engine.loopNeedSec());
                else if (engine.loopFailed())
                    std::snprintf (t, sizeof t, deck ? "LOOP %s: play the sample first (%.1f s)" : "LOOP %s: play %.1f s of audio first", kLoopNames[clampi (loopIdxActive, 0, kNumLoops - 1)], engine.loopNeedSec());
                else if (deck)
                {
                    if (! ioOk()) std::snprintf (t, sizeof t, "SAMPLE: no DJ Scratch folder on the drive");
                    else if (! engine.deckLoaded()) std::snprintf (t, sizeof t, "SAMPLE: put WAVs in DJ Scratch/Samples");
                    else std::snprintf (t, sizeof t, "%s %s  %.1f/%.1f s%s", engine.deckAtEnd() ? "END " : (get (P_PLAY) > 0.5f ? "PLAY" : "STOP"),
                                        nm, (double) engine.deckPosSec(), (double) engine.deckLenSec(), tail);
                }
                else
                {
                    const float pk = engine.inputPeak();
                    char in[24];
                    if (pk < 0.00003f) std::snprintf (in, sizeof in, "IN: no signal");
                    else std::snprintf (in, sizeof in, "IN %+.0f dB", (double) (20.f * std::log10 (pk)));
                    std::snprintf (t, sizeof t, "LIVE  %s  %s%s", in, tempo, tail);
                    if (std::fabs (speedNow() - 1.0) > 1e-6)
                        std::snprintf (t, sizeof t, shiftMode() ? "LIVE  PITCH %+.1f %%  %s%s" : "LIVE (at now)  PITCH %+.1f %%  %s%s", (speedNow() - 1.0) * 100.0, in, tail);
                }
                break;
        }
        // messages (a sample loaded, a control learned, errors) take over the line for 3 s; the newest one wins
        const int g = ioMsgGen.load(), gm = midiMsgGen.load();
        if (g != seenMsgGen) { seenMsgGen = g; msgLeft = (int) (sr * 3.f); msgFromMidi = false; }
        if (gm != seenMidiGen) { seenMidiGen = gm; msgLeft = (int) (sr * 3.f); msgFromMidi = true; }
        if (msgLeft > 0) std::snprintf (t, sizeof t, "%s", msgFromMidi ? midiMsg.get() : ioMsg.get());
        // MIDI LEARN guides you through it
        if (learnArmed())
        {
            const int tg = learnTarget.load();
            if (tg < 0) std::snprintf (t, sizeof t, "MIDI LEARN: touch a control on the screen");
            else std::snprintf (t, sizeof t, "MIDI LEARN: move a knob or press a button for %s", kParams[tg].name);
        }
        if (! info.publish (t)) return;
        infoGen = (infoGen + 1) % 1000;
        send (P_INFO, (float) infoGen, 0.5f);
    }
    // ---------------------------------------------------------------- the deck's keys and springs (audio thread)
    // the latest roll key pressed wins and the others go out; releasing the active one ends the roll
    void rollKeys()
    {
        for (int k = 0; k < kNumRoll; ++k)
        {
            const bool on = get (kRollParam[k]) > 0.5f;
            if (on && ! rollWas[k])
            {
                rollActive = k;
                for (int j = 0; j < kNumRoll; ++j) if (j != k && get (kRollParam[j]) > 0.5f) { send (kRollParam[j], 0.f, 0.f); rollWas[j] = false; }
            }
            else if (! on && rollWas[k] && rollActive == k) rollActive = -1;
            rollWas[k] = get (kRollParam[k]) > 0.5f;
        }
        if (rollActive >= 0 && get (kRollParam[rollActive]) < 0.5f) rollActive = -1;
    }
    void deckControls (int n, Settings& s)
    {
        if (pending[P_BRAKE].exchange (0) > 0)                                     // BRAKE: stop now, hard
        {
            if (get (P_PLAY) > 0.5f) { braking = true; send (P_PLAY, 0.f, 0.f); }
            send (P_BRAKE, 0.f, 0.f);
        }
        if (get (P_PLAY) > 0.5f) braking = false;
        if (pending[P_PRESET].exchange (0) > 0) { send (P_PITCH, 0.f, 0.f); send (P_PFINE, 0.f, 0.f); send (P_BEND, 0.f, 0.f); send (P_PRESET, 0.f, 0.f); }
        const float b = get (P_BEND);                                              // BEND springs back once you let go of it
        if (b != lastBend) { lastBend = b; bendIdle = 0; }
        else if (b != 0.f && ! midiBendHeld && (bendIdle += n) > (int) (0.15f * sr)) { send (P_BEND, 0.f, 0.f); lastBend = 0.f; }
        applySpeed (s); s.motorOn = get (P_PLAY) > 0.5f; s.stopSec = braking ? 0.12f : get (P_STOPT);
    }
    // the spinning record and the input meter on the screen (~25 updates a second)
    void visuals (int n)
    {
        angle += engine.takeMotion() / (double) sr * (100.0 / 3.0 / 60.0);       // 33 1/3 rpm at 1x
        angle -= std::floor (angle);
        visualCountdown -= n;
        if (visualCountdown > 0) return;
        visualCountdown += (int) (sr / 25.f);
        send (P_SPIN, (float) angle, 0.004f);
        const float pk = engine.inputPeak();
        const float m = pk < 1e-6f ? 0.f : clampf ((20.f * std::log10 (pk) + 60.f) / 60.f, 0.f, 1.f);
        send (P_INMETER, m, 0.015f);
    }
    void process (const float* inL, const float* inR, float* outL, float* outR, int n)
    {
        midiControl (n);
        Settings s = settings();
        readHostTime (s);
        if (get (P_NOTES) < 0.5f && noteMask.load() != 0) { noteMask.store (0); noteLast.store (-1); }
        const int held = noteLast.load();
        rollKeys();
        const int roll = rollActive >= 0 ? kRollLoop[rollActive] : -1;
        const int loopIdx = held >= 0 ? held : (roll >= 0 ? roll : clampi ((int) get (P_LOOPLEN), 0, kNumLoops - 1));
        loopIdxActive = loopIdx;
        s.loopOn = get (P_LOOP) > 0.5f || held >= 0 || roll >= 0;
        s.loopBeats = kLoopBars[loopIdx] > 0 ? kLoopBars[loopIdx] * barBeats : kLoopBeats[loopIdx];
        s.tOn = get (P_TFORM) > 0.5f; s.tStepBeats = kRateBeats[clampi ((int) get (P_TRATE), 0, 5)];
        s.tDuty = get (P_TDUTY) * 0.01f; s.tMask = kPatMask[clampi ((int) get (P_TPAT), 0, 3)];
        if (tformDirty.exchange (0)) send (P_TFORM, get (P_TFORM), 0.f);
        // taps on the trigger keys: act on them, then let the key spring back
        if (pending[P_BACKSPIN].exchange (0) > 0) { engine.triggerBackspin(); send (P_BACKSPIN, 0.f, 0.f); }
        if (pending[P_CHOP].exchange (0) > 0) { engine.triggerChop(); send (P_CHOP, 0.f, 0.f); }
        if (pending[P_CUE].exchange (0) > 0) { engine.triggerCue(); send (P_CUE, 0.f, 0.f); }
        if (pending[P_RESCAN].exchange (0) > 0) { rescanReq.store (1); send (P_RESCAN, 0.f, 0.f); }
        deckControls (n, s);
        if (float* m = nextRing.exchange (nullptr))                               // HISTORY changed: the new ring
        {
            const uint32_t nf = nextRingFrames.load();
            retiredRing.store (engine.adoptRing (m, nf));
            ringFramesNow.store (nf);
        }
        // a new record from the I/O thread: put it on the platter, hand the old one back to be freed
        if (dsio::Sample* ns = next.exchange (nullptr))
        {
            dsio::Sample* old = cur; cur = ns;
            engine.setRecord (ns->l, ns->r, ns->len);
            if (old != nullptr) retired.store (old);
        }
        engine.process (inL, inR, outL, outR, n, s);
        if (engine.takeHandTookLoop())                                             // the hand took over: every loop source goes out
        {
            noteMask.store (0); noteLast.store (-1);
            if (get (P_LOOP) > 0.5f) send (P_LOOP, 0.f, 0.f);
            for (int k = 0; k < kNumRoll; ++k) if (get (kRollParam[k]) > 0.5f) { send (kRollParam[k], 0.f, 0.f); rollWas[k] = false; }
            rollActive = -1;
        }
        // hand off the record: bring the platter control back to the middle so the next scratch has room both ways
        if (engine.state() != Engine::GRAB && std::fabs (s.platter - 0.5f) > 0.002f)
        {
            engine.notePlatter (0.5f);
            send (P_PLATTER, 0.5f, 0.f);
        }
        visuals (n);
        if (msgLeft > 0) msgLeft -= n;
        displayCountdown -= n;
        if (displayCountdown <= 0) { displayCountdown += (int) (sr / 15.f); updateDisplay(); }
    }
    void display (int idx, char* out, size_t max)
    {
        const ParamDef& d = kParams[idx];
        const float p = v[idx].load();
        if (idx == P_INFO) { std::snprintf (out, max, "%s", info.get()); return; }
        if (d.kind == K_CHOICE) { std::snprintf (out, max, "%s", d.choices[clampi ((int) p, 0, d.n - 1)]); return; }
        if (d.kind == K_BOOL)
        {
            if (isTrigger (idx)) { std::snprintf (out, max, "Tap"); return; }
            std::snprintf (out, max, "%s", p >= 0.5f ? "On" : "Off"); return;
        }
        switch (d.fmt)
        {
            case F_DB: std::snprintf (out, max, "%+.1f dB", (double) p); return;
            case F_SEC: std::snprintf (out, max, "%.2f s", (double) p); return;
            case F_MS: std::snprintf (out, max, p < 10.f ? "%.1f ms" : "%.0f ms", (double) p); return;
            case F_X: std::snprintf (out, max, "%.1fx", (double) p); return;
            case F_PLATTER: std::snprintf (out, max, "%+.0f", (double) ((p - 0.5f) * 200.f)); return;
            case F_BPM: if (p < 1.f) std::snprintf (out, max, "Host"); else std::snprintf (out, max, "%.0f", (double) p); return;
            case F_PCT: std::snprintf (out, max, "%.0f %%", (double) p); return;
            case F_PITCH: std::snprintf (out, max, "%+.1f %%", (double) p * kRangePct[clampi ((int) get (P_PRANGE), 0, 2)]); return;
            case F_FINE:  std::snprintf (out, max, "%+.2f %%", (double) p); return;
            case F_BEND:  std::snprintf (out, max, "%+.1f %%", (double) p * kBendPct); return;
            case F_SPIN:  std::snprintf (out, max, "%.0f deg", (double) p * 360.0); return;
            case F_METER: if (p <= 0.f) std::snprintf (out, max, "-inf dB"); else std::snprintf (out, max, "%.0f dB", (double) p * 60.0 - 60.0); return;
            case F_SAMPLE:
            {
                char nm[64]; int cnt = 0;
                const int i = clampi ((int) p, 0, kMaxFiles - 1);
                if (fileShown (i, nm, sizeof nm, &cnt)) std::snprintf (out, max, "%d/%d %s", i + 1, cnt, nm);
                else if (cnt == 0) std::snprintf (out, max, "(no WAVs)");
                else std::snprintf (out, max, "%d: (empty)", i + 1);
                return;
            }
            default: std::snprintf (out, max, "%.2f", (double) p); return;
        }
    }
    static int clampi (int x, int lo, int hi) { return x < lo ? lo : (x > hi ? hi : x); }
};

// ---------------------------------------------------------------------------------------------- VST2 entry points
void processReplacing (AEffect* e, float** in, float** out, int32_t n)
{
    Plugin* p = static_cast<Plugin*> (e->object);
    for (int32_t pos = 0; pos < n; pos += Plugin::kChunk)
    {
        const int32_t m = (n - pos) < Plugin::kChunk ? (n - pos) : Plugin::kChunk;
        p->process (in[0] + pos, in[1] + pos, out[0] + pos, out[1] + pos, m);
    }
}
void processAccumulating (AEffect* e, float** in, float** out, int32_t n)
{
    float tl[256], tr[256];
    Plugin* p = static_cast<Plugin*> (e->object);
    for (int32_t pos = 0; pos < n; pos += 256)
    {
        const int32_t m = (n - pos) < 256 ? (n - pos) : 256;
        p->process (in[0] + pos, in[1] + pos, tl, tr, m);
        for (int32_t i = 0; i < m; ++i) { out[0][pos + i] += tl[i]; out[1][pos + i] += tr[i]; }
    }
}
void setParameter (AEffect* e, int32_t i, float norm) { if (i >= 0 && i < P_COUNT) static_cast<Plugin*> (e->object)->setNorm (i, norm); }
float getParameter (AEffect* e, int32_t i) { return (i >= 0 && i < P_COUNT) ? static_cast<Plugin*> (e->object)->nv[i].load() : 0.f; }
intptr_t dispatcher (AEffect* e, int32_t op, int32_t idx, intptr_t val, void* ptr, float opt)
{
    Plugin* p = static_cast<Plugin*> (e->object);
    switch (op)
    {
        case effClose:            p->~Plugin(); std::free (p); return 0;
        case effSetProgram:       p->applyPreset ((int) val); p->notifyHostAll(); return 0;
        case effGetProgram:       return p->program;
        case effGetProgramName:   copyStr (ptr, kPresets[p->program].name); return 0;
        case effGetProgramNameIndexed: if (idx < 0 || idx >= kNumPresets) return 0; copyStr (ptr, kPresets[idx].name); return 1;
        case effGetParamName:     if (idx >= 0 && idx < P_COUNT) copyStr (ptr, kParams[idx].name); return 0;
        case effGetParamLabel:    if (idx >= 0 && idx < P_COUNT) copyStr (ptr, kParams[idx].unit, 8); return 0;
        case effGetParamDisplay:  if (idx >= 0 && idx < P_COUNT && ptr != nullptr) { char b[96]; p->display (idx, b, sizeof b); copyStr (ptr, b, 64); } return 0;
        case effCanBeAutomated:   return (idx >= 0 && idx < P_COUNT && ! isReadout (idx)) ? 1 : 0;
        case effSetSampleRate:    if (opt > 1000.f) { p->sr = opt; p->srA.store (opt); p->prepareEngine (opt); } return 0;
        case effMainsChanged:     if (val) p->prepareEngine (p->sr); return 0;
        case effSetBypass:        p->setPlain (P_BYPASS, val ? 1.f : 0.f); return 1;
        case effProcessEvents:    p->midiEvents (static_cast<const VstEvents*> (ptr)); return 1;
        case effGetEffectName:
        case effGetProductString: copyStr (ptr, "DJ Scratch", 32); return 1;
        case effGetVendorString:  copyStr (ptr, "ScratchLab", 32); return 1;
        case effGetVendorVersion: return 1700;
        case effGetPlugCategory:  return kPlugCategEffect;
        case effGetVstVersion:    return 2400;
        case effGetTailSize:      return 1;
        case effSetProcessPrecision: return val == 0 ? 1 : 0;
        case effCanDo:
            if (ptr != nullptr && (std::strcmp ((const char*) ptr, "bypass") == 0 || std::strcmp ((const char*) ptr, "receiveVstEvents") == 0
                                   || std::strcmp ((const char*) ptr, "receiveVstMidiEvent") == 0)) return 1;
            return 0;
        default: return 0;
    }
}
void initOnce() { static bool done = false; if (! done) { initParams(); done = true; } }
} // namespace

DS_EXPORT AEffect* VSTPluginMain (audioMasterCallback master)
{
    initOnce();
    void* mem = std::calloc (1, sizeof (Plugin));   // no operator new: keeps libstdc++ out of the link
    if (mem == nullptr) return nullptr;
    Plugin* p = new (mem) Plugin();
    p->master = master;
    p->applyPreset (0);
    p->startIO();
    AEffect& fx = p->fx;
    fx.magic = kEffectMagic;
    fx.dispatcher = dispatcher;
    fx.process = processAccumulating;
    fx.processReplacing = processReplacing;
    fx.setParameter = setParameter;
    fx.getParameter = getParameter;
    fx.numPrograms = kNumPresets;
    fx.numParams = P_COUNT;
    fx.numInputs = 2;
    fx.numOutputs = 2;
    fx.flags = effFlagsCanReplacing;
    fx.initialDelay = 0;
    fx.ioRatio = 1.f;
    fx.object = p;
    fx.uniqueID = ('D' << 24) | ('J' << 16) | ('S' << 8) | 'C';   // 'DJSC' = 0x444A5343
    fx.version = 1700;
    return &fx;
}
// stable parameter keys for tools/make_skin.py
DS_EXPORT const char* DS_ParamKey (int i) { initOnce(); return (i >= 0 && i < P_COUNT) ? kParams[i].key : ""; }
DS_EXPORT int DS_ParamCount() { return P_COUNT; }
DS_EXPORT const char* DS_PresetName (int i) { return (i >= 0 && i < kNumPresets) ? kPresets[i].name : ""; }
DS_EXPORT int DS_PresetCount() { return kNumPresets; }
