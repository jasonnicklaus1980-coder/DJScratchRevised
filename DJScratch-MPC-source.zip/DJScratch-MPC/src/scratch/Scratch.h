// DJ Scratch engine: records the incoming audio all the time into a ring buffer and lets you "scratch" it like a record.
//
//   LIVE    the plugin is transparent (bit-exact pass-through, zero latency).
//   GRAB    a hand is on the record: the read head follows the PLATTER control (a jog wheel), so moving it back and
//           forth plays the last seconds of incoming audio backwards / forwards at the speed you move it. Held still = silence.
//   SPIN    backspin: the head spins backwards fast and slows to a stop.
//   RETURN  (Catch-up mode) the record spins up and races forward until it reaches the live signal again.
//
// Leaving GRAB / SPIN, SLIP mode crossfades straight back to the live signal (the beat kept playing underneath, like
// a DJ mixer's slip mode); CATCH-UP mode fast-forwards to it.
//   LOOP    loops the last N beats of the incoming audio (a note value: 1/8, 1/16 ...) until released. While a loop runs the
//           plugin is not recording (the loop is the last audio it heard), and it crossfades back to live on release.
// TRANSFORMER (separate from the states): a tempo-synced gate that chops the output in a pattern, locked to the host's beat
// position when the transport plays and free-running otherwise. The CUT fader mutes the output (crossfader), CHOP taps it
// for a moment (a "transform" scratch).
//
// SAMPLE source (Settings::deck): instead of the incoming audio, the record is a sample loaded from disk (setRecord). A motor
// turns it at 1x (PLAY, with a start/stop ramp like a real deck), CUE drops the needle back at the start, and the same
// platter / backspin / loop / fader / transformer act on it. The incoming audio passes through underneath (THRU), so you
// scratch the sample over the beat. Return mode in SAMPLE: Slip = the record kept turning under your hand; Catch up =
// "vinyl": the record picks up from where your hand left it.
//
// THE MOTOR (both sources). START/STOP spins the platter up over Start Time and brakes it over Stop Time; PITCH, 33/45 and
// REVERSE set the speed the motor pulls towards. On the live input the motor works on the history: stop it and the incoming
// audio winds down to a halt (a "power-off" stop), start it and the record spins back up from where it stopped, then
// slips (or catches up) back to the live signal once it is at speed. Pitched down, the record falls behind the live signal;
// pitched up, it can only catch up with "now" (nobody can play the future). REVERSE plays the history backwards.
// Letting go of the record (GRAB) with the motor not at normal speed hands it back to the motor through the slipmat: the
// record's speed follows the platter within ~50 ms (state PLAY).
//
// Audio-thread only (except prepare/setRingSeconds on the host thread). No libstdc++: plain C arrays, one calloc in prepare().
#pragma once
#include <cmath>
#include <math.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

namespace ds
{
inline float clampf (float v, float lo, float hi) { return v < lo ? lo : (v > hi ? hi : v); }
inline double clampd (double v, double lo, double hi) { return v < lo ? lo : (v > hi ? hi : v); }

struct Settings
{
    float platter = 0.5f;       // 0..1 jog position (0.5 = centre)
    bool hold = false;          // keep a hand on the record
    bool autoGrab = true;       // moving the platter grabs the record, and it lets go after releaseSec of stillness
    float releaseSec = 0.4f;
    float throwSec = 1.0f;      // seconds of audio covered by the full 0..1 platter range
    float inertiaMs = 12.f;     // how heavy the platter feels (smoothing)
    bool faderClosed = false;   // crossfader: output muted while true
    float chopMs = 80.f;        // length of a CHOP tap
    float cutMs = 2.f;          // fader open/close time
    float spinSpeed = 8.f;      // backspin start speed (x normal)
    float spinSec = 1.2f;       // backspin duration
    int returnMode = 0;         // 0 = slip (jump back to live), 1 = catch up (fast-forward back)
    float catchSpeed = 3.f;
    float outDb = 0.f;
    bool bypass = false;
    // loop (beat repeat of the last audio)
    bool loopOn = false;
    double loopBeats = 1.0;     // loop length in quarter-note beats (1/8 note = 0.5)
    // tempo and position (the plugin gets these from the host, or the BPM control)
    double bpm = 120.0;
    double ppq = 0.0;           // host beat position, valid when ppqValid (transport playing)
    bool ppqValid = false;
    // transformer gate
    bool tOn = false;
    double tStepBeats = 0.25;   // length of one gate step
    float tDuty = 0.5f;         // fraction of each open step that is actually open
    uint32_t tMask = 0xFFFFu;   // which of 16 steps are open
    // the motor
    double speed = 1.0;         // what the motor pulls towards: 33/45, pitch fader, fine pitch and bend combined
    bool reverse = false;
    float startSec = 0.5f;      // 0 -> full speed
    float stopSec = 0.8f;       // full speed -> 0
    double shiftRatio = 1.0;    // SHIFT pitch mode (live source): the input's pitch, applied in real time before the deck
    // SAMPLE source: the record on the platter is a loaded sample instead of the incoming audio
    bool deck = false;
    bool motorOn = true;        // the deck's motor (PLAY): the record turns at 1x when on
    bool thru = true;           // in SAMPLE mode, pass the incoming audio through under the deck
};

// Real-time pitch shifter for the live input (SHIFT pitch mode): two read taps sweep a short delay line (50 ms window) with
// sin^2 crossfades, so the pitch moves instantly and the sound never drifts away from "now" (latency stays under 50 ms).
// At ratio 1 it fades out over 20 ms and the signal passes bit-exact. No allocation: a fixed 16384-frame buffer.
class PitchShifter
{
public:
    void reset() { memset (bl_, 0, sizeof bl_); memset (br_, 0, sizeof br_); w_ = 0; ph_ = 0; wet_ = 0; }
    bool active() const { return wet_ > 0.f; }
    inline void process (float& l, float& r, double ratio, double win, float wetStep)
    {
        const uint32_t wi = w_ & (N - 1);
        bl_[wi] = l; br_[wi] = r; ++w_;
        const float target = ratio != 1.0 ? 1.f : 0.f;
        if (wet_ < target) wet_ = std::fmin (wet_ + wetStep, 1.f); else if (wet_ > target) wet_ = std::fmax (wet_ - wetStep, 0.f);
        if (wet_ <= 0.f) { ph_ = 0; return; }                                     // dry: untouched
        if (ratio != 1.0) { ph_ += (1.0 - ratio) / win; ph_ -= std::floor (ph_); }
        double ph2 = ph_ + 0.5; ph2 -= std::floor (ph2);
        const double d1 = 4.0 + ph_ * win, d2 = 4.0 + ph2 * win;
        const double sn = std::sin (3.14159265358979 * ph_);
        const float g1 = (float) (sn * sn), g2 = 1.f - g1;
        const float sl = g1 * tap (bl_, d1) + g2 * tap (bl_, d2);
        const float sr = g1 * tap (br_, d1) + g2 * tap (br_, d2);
        l = l * (1.f - wet_) + sl * wet_;
        r = r * (1.f - wet_) + sr * wet_;
    }
private:
    static constexpr uint32_t N = 1u << 14;
    inline float tap (const float* b, double d) const
    {
        const double pos = (double) w_ - 1.0 - d;
        const int64_t i = (int64_t) std::floor (pos);
        const float f = (float) (pos - (double) i);
        const float y0 = b[(uint32_t) (i - 1) & (N - 1)], y1 = b[(uint32_t) i & (N - 1)], y2 = b[(uint32_t) (i + 1) & (N - 1)], y3 = b[(uint32_t) (i + 2) & (N - 1)];
        const float c1 = 0.5f * (y2 - y0), c2 = y0 - 2.5f * y1 + 2.f * y2 - 0.5f * y3, c3 = 0.5f * (y3 - y0) + 1.5f * (y1 - y2);
        return ((c3 * f + c2) * f + c1) * f + y1;
    }
    float bl_[N] {}, br_[N] {};
    uint32_t w_ = 0; double ph_ = 0; float wet_ = 0;
};

class Engine
{
public:
    enum State { LIVE = 0, GRAB = 1, SPIN = 2, RETURN = 3, LOOP = 4, PLAY = 5 };
    static uint32_t ringFramesFor (double sr, double sec)
    {
        uint32_t n = 1u << 16;
        while ((double) n < sr * sec && n < (1u << 25)) n <<= 1;
        return n;
    }

    Engine() {}
    ~Engine() { free (mem_); }
    Engine (const Engine&) = delete;
    Engine& operator= (const Engine&) = delete;

    // Host thread, before prepare(): how many seconds of history the ring keeps (rounded up to a power of two).
    void setRingSeconds (double sec) { ringSec_ = clampd (sec, 4.0, 180.0); }
    double ringSeconds() const { return ringSec_; }
    // Host thread (effSetSampleRate / effMainsChanged). Re-allocates only if the ring size changes.
    bool prepare (double sr)
    {
        sr_ = clampd (sr, 8000.0, 192000.0);
        const uint32_t n = ringFramesFor (sr_, ringSec_);
        if (n != size_)
        {
            float* m = (float*) calloc ((size_t) n * 2, sizeof (float));
            if (m == nullptr) return false;
            free (mem_);
            mem_ = m; size_ = n; mask_ = n - 1;
        }
        reset();
        return true;
    }
    // Audio thread: swap in a new (zeroed, calloc'd) ring of n frames made by another thread; returns the old one to free.
    // The history starts over.
    float* adoptRing (float* m, uint32_t n)
    {
        float* old = mem_;
        mem_ = m; size_ = n; mask_ = n - 1;
        resetState();
        return old;
    }
    void reset()
    {
        if (mem_ != nullptr) memset (mem_, 0, (size_t) size_ * 2 * sizeof (float));
        resetState();
    }
    void resetState()
    {
        wAbs_ = 0; recVel_ = 1; motorVel_ = 1; motion_ = 0; curT_ = 1; shifter_.reset(); head_ = p1_ = anchorR_ = 0; state_ = LIVE; xf_ = 0; xfTarget_ = 0; cut_ = 1; chopLeft_ = 0;
        idle_ = 1e9; lastPlatter_ = 0.5f; vel_ = 0; spinVel_ = 0; vRet_ = 0; anchorP_ = 0.5f;
        spinReq_ = chopReq_ = false;
        loopStart_ = loopLen_ = loopPos_ = 0; loopExiting_ = false; loopFail_ = false; loopBeatsAct_ = -1; loopXf_ = 0; swLeft_ = 0;
        internalBeats_ = 0; tg_ = 1;
        motorPos_ = 0; cueReq_ = false; cueState_ = 0; cueLeft_ = 0;
    }
    uint32_t ringSize() const { return size_; }
    // How far the record has turned since the last call, in frames of audio at normal speed (negative = backwards).
    double takeMotion() { const double m = motion_; motion_ = 0; return m; }
    float motorSpeed() const { return (float) motorVel_; }
    // true once after the hand took the record out of a loop (the plugin then turns the loop controls off)
    bool takeHandTookLoop() { const bool b = handTookLoop_; handTookLoop_ = false; return b; }

    void triggerBackspin() { spinReq_ = true; }
    void triggerCue() { cueReq_ = true; }
    // SAMPLE source: the record. l / r stay owned by the caller and must outlive their use (r may equal l for mono).
    void setRecord (const float* l, const float* r, int64_t len)
    {
        rl_ = l; rr_ = (r != nullptr) ? r : l; rlen_ = (l != nullptr && len > 0) ? len : 0;
        motorPos_ = 0; cueState_ = 0;
        if (deckMode_) { state_ = LIVE; xf_ = xfTarget_ = 0; head_ = p1_ = 0; loopExiting_ = false; spinVel_ = 0; }
    }
    bool deckMode() const { return deckMode_; }
    float deckPosSec() const { return (float) ((deckMode_ && state_ != LIVE && state_ != LOOP ? head_ : motorPos_) / sr_); }
    float deckLenSec() const { return (float) ((double) rlen_ / sr_); }
    bool deckLoaded() const { return rlen_ > 0; }
    bool deckAtEnd() const { return rlen_ > 0 && motorPos_ >= (double) rlen_ - 1.0; }
    void triggerChop() { chopReq_ = true; }
    // The plugin moved the platter control itself (re-centring): don't count it as a hand movement.
    void notePlatter (float p) { lastPlatter_ = p; }
    // Move the platter control from 'from' to 'to' without moving the needle (an endless MIDI jog wheel re-centres it this way,
    // mid-scratch): the anchor moves with it, so the hand's target position stays exactly where it was.
    void shiftPlatter (float from, float to) { anchorP_ += to - from; lastPlatter_ = to; }

    State state() const { return state_; }
    bool idleLive() const { return state_ == LIVE && xf_ <= 0.f; }
    float velocity() const { return (float) vel_; }
    float behindSec() const { return (float) ((double) wAbs_ - head_) / (float) sr_; }
    float loopSec() const { return (float) ((double) loopLen_ / sr_); }
    float inputPeak() const { return inPeak_; }          // incoming signal level (linear peak of the last block, slow decay)
    bool loopFailed() const { return loopFail_; }       // a loop was asked for but there is not enough recorded audio yet
    bool loopFailedTooLong() const { return loopFail_ && loopFailLong_; }   // ...and it never could be: longer than the History
    double loopNeedSec() const { return loopNeedSec_; }   // how much audio the last loop asked for needs
    double sampleRate() const { return sr_; }

    void process (const float* inL, const float* inR, float* outL, float* outR, int n, const Settings& s)
    {
        if (mem_ == nullptr)
        {
            if (outL != inL) memcpy (outL, inL, sizeof (float) * (size_t) n);
            if (outR != inR) memcpy (outR, inR, sizeof (float) * (size_t) n);
            return;
        }
        float* const bl = mem_;
        float* const br = mem_ + size_;
        const double sr = sr_;
        const float p = clampf (s.platter, 0.f, 1.f);
        { float pk = 0.f; for (int i = 0; i < n; ++i) { const float a = std::fmax (std::fabs (inL[i]), std::fabs (inR[i])); if (a > pk) pk = a; } inPeak_ = std::fmax (pk, inPeak_ * 0.9f); }
        if (s.deck != deckMode_)                                  // source switched: start over in the new mode, hand off the record
        {
            deckMode_ = s.deck; state_ = LIVE; xf_ = xfTarget_ = 0; loopExiting_ = false; loopFail_ = false; spinReq_ = false;
            spinVel_ = 0; idle_ = 1e9; cueState_ = 0;
            head_ = p1_ = anchorR_ = deckMode_ ? motorPos_ : (double) wAbs_ - 3.0;
        }
        if (deckMode_) { processDeck (inL, inR, outL, outR, n, s); return; }

        // ---------------------------------------------------------------- block-level control
        const bool moved = std::fabs (p - lastPlatter_) > 1e-5f;
        const double relFrames = clampd (s.releaseSec, 0.05, 10.0) * sr;
        if (! s.autoGrab) idle_ = 1e9; else if (moved) idle_ = 0; else idle_ += n;
        const bool wantGrab = ! s.bypass && (s.hold || (s.autoGrab && idle_ < relFrames));
        const float engageP = moved ? lastPlatter_ : p;     // the move that grabbed the record counts

        curT_ = s.bypass ? 1.0 : (s.motorOn ? clampd (s.speed, 0.05, 4.0) * (s.reverse ? -1.0 : 1.0) : 0.0);
        if (s.bypass) { state_ = LIVE; xf_ = xfTarget_ = 0; spinReq_ = false; loopExiting_ = false; loopFail_ = false; motorVel_ = recVel_ = 1; }
        if (chopReq_) { chopReq_ = false; chopLeft_ = (int64_t) (clampd (s.chopMs, 5.0, 2000.0) * 0.001 * sr); }
        const bool atNormal = curT_ == 1.0 && motorVel_ == 1.0;

        const double hiLive = (double) wAbs_ - 3.0;
        const bool wantLoop = ! s.bypass && s.loopOn;
        if (wantLoop)
        {
            const bool active = state_ == LOOP && ! loopExiting_;
            if (state_ != GRAB && (! active || loopBeatsAct_ != s.loopBeats)) engageLoop (s);     // a hand on the record wins
        }
        else
        {
            loopFail_ = false;
            if (state_ == LOOP && ! loopExiting_) { loopExiting_ = true; xfTarget_ = 0; }
        }
        if (spinReq_)
        {
            spinReq_ = false;
            if (! s.bypass && state_ != LOOP)
            {
                if (state_ == LIVE && xf_ <= 0.f) head_ = hiLive;
                p1_ = head_; state_ = SPIN; spinVel_ = -clampd (s.spinSpeed, 1.0, 16.0); xfTarget_ = 1;
            }
        }
        switch (state_)
        {
            case LIVE:
                if (wantGrab) { head_ = p1_ = anchorR_ = (xf_ <= 0.f) ? hiLive : head_; anchorP_ = engageP; state_ = GRAB; xfTarget_ = 1; }
                else if (! atNormal && ! s.bypass && xf_ <= 0.f && ! loopExiting_)
                { head_ = p1_ = hiLive; recVel_ = motorVel_; state_ = PLAY; xfTarget_ = 1; }     // the motor changed: the record leaves "now"
                break;
            case PLAY:
                if (wantGrab) { p1_ = anchorR_ = head_; anchorP_ = engageP; state_ = GRAB; }
                break;
            case LOOP:
                if (wantGrab && moved && ! loopExiting_)          // the hand takes the record from wherever the loop is
                {
                    head_ = p1_ = anchorR_ = (double) (loopStart_ + loopPos_); anchorP_ = engageP;
                    state_ = GRAB; xfTarget_ = 1; xf_ = 1; handTookLoop_ = true;
                }
                break;
            case GRAB:
                if (! wantGrab) release (s);
                break;
            case SPIN:
                if (wantGrab) { p1_ = anchorR_ = head_; anchorP_ = engageP; spinVel_ = 0; state_ = GRAB; }
                break;
            case RETURN:
                if (wantGrab) { p1_ = anchorR_ = head_; anchorP_ = engageP; state_ = GRAB; }
                else if (curT_ != 1.0) { recVel_ = vRet_; state_ = PLAY; }
                break;
        }

        const double accUp = 1.0 / (clampd (s.startSec, 0.05, 5.0) * sr);        // motor torque: constant acceleration
        const double accDn = 1.0 / (clampd (s.stopSec, 0.05, 10.0) * sr);
        const double aSlip = 1.0 - std::exp (-1.0 / (0.012 * sr));               // the record catches the platter through the slipmat
        const double shiftRatio = s.bypass ? 1.0 : clampd (s.shiftRatio, 0.25, 4.0);
        const double shiftWin = 0.05 * sr;
        const float shiftStep = (float) (1.0 / (0.02 * sr));
        const double tauPole = clampd (s.inertiaMs, 2.0, 100.0) * 0.001 * 0.5;       // two cascaded poles
        const double a = 1.0 - std::exp (-1.0 / (tauPole * sr));
        const double aRet = 1.0 - std::exp (-1.0 / (0.015 * sr));
        const double spinDecay = std::exp (-1.0 / ((clampd (s.spinSec, 0.1, 6.0) / 4.6) * sr));
        const double throwFrames = clampd (s.throwSec, 0.1, 4.0) * sr;
        const double catchSpd = clampd (s.catchSpeed, 1.5, 8.0);
        const float xfStep = (float) (1.0 / (0.005 * sr));
        const float cutStep = (float) (1.0 / (clampd (s.cutMs, 0.2, 50.0) * 0.001 * sr));
        const float gain = std::pow (10.f, clampf (s.outDb, -60.f, 24.f) / 20.f);
        const double vmax = 12.0;
        const double bpf = clampd (s.bpm, 40.0, 240.0) / 60.0 / sr;                 // beats per frame
        const double beat0 = s.ppqValid ? s.ppq : internalBeats_;
        const double stepBeats = clampd (s.tStepBeats, 0.05, 4.0);
        const double duty = clampd ((double) s.tDuty, 0.05, 1.0);

        // ---------------------------------------------------------------- audio
        for (int i = 0; i < n; ++i)
        {
            float l = inL[i], r = inR[i];
            if (shiftRatio != 1.0 || shifter_.active()) shifter_.process (l, r, shiftRatio, shiftWin, shiftStep);
            if (! (state_ == LOOP && ! loopExiting_))                   // a running loop freezes the recording
            {
                const uint32_t wi = (uint32_t) (wAbs_ & mask_);
                bl[wi] = l; br[wi] = r;
                ++wAbs_;
            }
            const double hi = (double) wAbs_ - 3.0;
            const double lo = (double) wAbs_ - (double) size_ + 8.0;
            stepMotor (accUp, accDn);

            double v = 1.0;
            switch (state_)
            {
                case PLAY:
                {
                    recVel_ += (motorVel_ - recVel_) * aSlip;
                    if (std::fabs (recVel_ - motorVel_) < 1e-4) recVel_ = motorVel_;
                    const double h0 = head_;
                    head_ = clampd (head_ + recVel_, lo, hi);
                    v = head_ - h0;                                              // what the needle really did (stuck at "now" = 1x)
                    if (curT_ == 1.0 && motorVel_ == 1.0 && recVel_ == 1.0)        // back at normal speed
                    {
                        if (head_ >= hi - 1.0) { state_ = LIVE; xfTarget_ = 0; }  // already at "now"
                        else release (s);                                       // behind: slip or catch up, as set
                    }
                    else if (head_ <= lo + 1.0)                                  // ran out of history
                    {
                        if (std::fabs (recVel_) < 0.01) head_ = hi;              // stopped: nothing to hear, keep it at "now"
                        else { state_ = LIVE; xfTarget_ = 0; }                   // slip back to live, then the motor takes it again
                    }
                    break;
                }
                case GRAB:
                {
                    const double t = clampd (anchorR_ + (double) (p - anchorP_) * throwFrames, lo, hi);
                    p1_ += (t - p1_) * a;
                    double d = (p1_ - head_) * a;
                    d = clampd (d, -vmax, vmax);
                    head_ += d; v = d;
                    break;
                }
                case SPIN:
                    v = spinVel_; head_ += v; spinVel_ *= spinDecay;
                    if (std::fabs (spinVel_) < 0.04 || head_ <= lo) { head_ = clampd (head_, lo, hi); endSpin (s); }
                    break;
                case RETURN:
                    vRet_ += (catchSpd - vRet_) * aRet; v = vRet_; head_ += v;
                    if (head_ >= hi) { head_ = hi; state_ = LIVE; xfTarget_ = 0; v = 1.0; }
                    break;
                case LIVE:
                    v = 1.0;
                    if (xf_ > 0.f) head_ += 1.0; else head_ = hi;
                    break;
                case LOOP:
                    v = 1.0;
                    break;
            }
            if (state_ != LOOP) head_ = clampd (head_, lo, hi);
            vel_ = v; motion_ += v;

            if (xf_ < xfTarget_) xf_ = std::fmin (xf_ + xfStep, xfTarget_); else if (xf_ > xfTarget_) xf_ = std::fmax (xf_ - xfStep, xfTarget_);
            if (state_ == LOOP && loopExiting_ && xf_ <= 0.f) { state_ = LIVE; loopExiting_ = false; head_ = p1_ = hi; }

            float oL = l, oR = r;
            if (xf_ > 0.f)
            {
                float pl, pr;
                if (state_ == LOOP) loopSample (bl, br, pl, pr);
                else
                {
                    const int64_t ii = (int64_t) std::floor (head_);
                    const float f = (float) (head_ - (double) ii);
                    pl = hermite (bl, ii, f); pr = hermite (br, ii, f);
                    float g = clampf ((float) std::fabs (v) * 5.f, 0.f, 1.f);      // a stopped record is silent
                    g = g * g * (3.f - 2.f * g);
                    pl *= g; pr *= g;
                }
                if (state_ == LOOP)                                       // live <-> loop: S-curve
                {
                    if (xf_ >= 1.f) { oL = pl; oR = pr; }
                    else { const float a = sfade (1.f - xf_), b = 1.f - a; oL = l * a + pl * b; oR = r * a + pr * b; }
                }
                else { oL = l * (1.f - xf_) + pl * xf_; oR = r * (1.f - xf_) + pr * xf_; }
            }
            else if (state_ == LIVE) { p1_ = head_; }

            const bool closed = s.faderClosed != (chopLeft_ > 0);
            if (chopLeft_ > 0) --chopLeft_;
            const float ct = closed ? 0.f : 1.f;
            if (cut_ < ct) cut_ = std::fmin (cut_ + cutStep, ct); else if (cut_ > ct) cut_ = std::fmax (cut_ - cutStep, ct);

            // transformer gate: the step comes from the beat position, so it stays on the grid
            {
                float tt = 1.f;
                if (s.tOn && ! s.bypass)
                {
                    const double sp = (beat0 + (double) i * bpf) / stepBeats, fl = std::floor (sp);
                    const int si = (int) (((int64_t) fl % 16 + 16) % 16);
                    tt = (((s.tMask >> si) & 1u) != 0 && (sp - fl) < duty) ? 1.f : 0.f;
                }
                if (tg_ < tt) tg_ = std::fmin (tg_ + cutStep, tt); else if (tg_ > tt) tg_ = std::fmax (tg_ - cutStep, tt);
                if (tg_ != 1.f) { oL *= tg_; oR *= tg_; }
            }
            if (cut_ != 1.f) { oL *= cut_; oR *= cut_; }
            if (gain != 1.f) { oL *= gain; oR *= gain; }
            outL[i] = oL; outR[i] = oR;
        }
        lastPlatter_ = p;
        internalBeats_ = beat0 + (double) n * bpf;
    }


private:
    // ================================================================ SAMPLE source (the deck)
    inline float rs (const float* b, int64_t i) const { return (i >= 0 && i < rlen_) ? b[i] : 0.f; }     // silent outside the record
    inline float hermiteRec (const float* b, double pos) const
    {
        const int64_t i = (int64_t) std::floor (pos);
        const float f = (float) (pos - (double) i);
        const float y0 = rs (b, i - 1), y1 = rs (b, i), y2 = rs (b, i + 1), y3 = rs (b, i + 2);
        const float c1 = 0.5f * (y2 - y0);
        const float c2 = y0 - 2.5f * y1 + 2.f * y2 - 0.5f * y3;
        const float c3 = 0.5f * (y3 - y0) + 1.5f * (y1 - y2);
        return ((c3 * f + c2) * f + c1) * f + y1;
    }
    static inline float speedGain (double v)                 // a stopped (or nearly stopped) record is silent
    {
        float g = clampf ((float) std::fabs (v) * 5.f, 0.f, 1.f);
        return g * g * (3.f - 2.f * g);
    }
    bool engageLoopDeck (const Settings& s)
    {
        const double bpm = clampd (s.bpm, 40.0, 240.0);
        int64_t L = (int64_t) std::llround (clampd (s.loopBeats, 0.0625, kMaxLoopBeats) * 60.0 / bpm * sr_);
        loopNeedSec_ = (double) L / sr_; loopFailLong_ = false;
        int64_t xf = (int64_t) (0.002 * sr_); if (xf < 16) xf = 16;
        const int64_t needle = (int64_t) std::floor (motorPos_);
        const int64_t have = (needle < rlen_ ? needle : rlen_) - xf - 8;          // the record played so far
        if (rlen_ <= 0 || L < 64 || L > have) { loopFail_ = true; return false; }
        if (xf > L / 2) xf = L / 2;
        if (state_ == LOOP && ! loopExiting_ && xf_ >= 1.f)
        {
            oStart_ = loopStart_; oLen_ = loopLen_; oPos_ = loopPos_; oXf_ = loopXf_;
            swLen_ = (int64_t) (0.006 * sr_); if (swLen_ < 16) swLen_ = 16; swLeft_ = swLen_;
        }
        loopFail_ = false; loopLen_ = L; loopStart_ = needle - L; loopPos_ = 0; loopXf_ = xf;
        loopBeatsAct_ = s.loopBeats; loopExiting_ = false; state_ = LOOP; xfTarget_ = 1; spinVel_ = 0;
        return true;
    }
    inline void loopSampleRec (float& pl, float& pr)
    {
        loopOut ([this] (int64_t i, float& a, float& b) { a = rs (rl_, i); b = rs (rr_, i); }, pl, pr);
    }
    void releaseDeck (const Settings& s)
    {
        if (s.returnMode == 1) { state_ = RETURN; vRet_ = vel_; }         // vinyl: the record picks up from under your hand
        else { state_ = LIVE; xfTarget_ = 0; }                           // slip: back to where the record would have been
    }

    void processDeck (const float* inL, const float* inR, float* outL, float* outR, int n, const Settings& s)
    {
        float* const bl = mem_;
        float* const br = mem_ + size_;
        const double sr = sr_;
        const float p = clampf (s.platter, 0.f, 1.f);
        const bool vinyl = s.returnMode == 1;
        const double lo = 0.0, hi = (double) rlen_;

        if (s.bypass)
        {
            for (int i = 0; i < n; ++i)
            {
                const uint32_t wi = (uint32_t) (wAbs_ & mask_); bl[wi] = inL[i]; br[wi] = inR[i]; ++wAbs_;
                outL[i] = inL[i]; outR[i] = inR[i];
            }
            state_ = LIVE; xf_ = xfTarget_ = 0; spinReq_ = false; loopExiting_ = false; loopFail_ = false; cueReq_ = false; cueState_ = 0;
            head_ = p1_ = motorPos_; lastPlatter_ = p; idle_ = 1e9; motion_ += n;
            return;
        }

        // ---------------------------------------------------------------- block-level control (same rules as the live record)
        const bool moved = std::fabs (p - lastPlatter_) > 1e-5f;
        const double relFrames = clampd (s.releaseSec, 0.05, 10.0) * sr;
        if (! s.autoGrab) idle_ = 1e9; else if (moved) idle_ = 0; else idle_ += n;
        const bool wantGrab = rlen_ > 0 && (s.hold || (s.autoGrab && idle_ < relFrames));
        const float engageP = moved ? lastPlatter_ : p;
        if (chopReq_) { chopReq_ = false; chopLeft_ = (int64_t) (clampd (s.chopMs, 5.0, 2000.0) * 0.001 * sr); }
        const int cueFade = (int) (0.003 * sr) > 8 ? (int) (0.003 * sr) : 8;
        if (cueReq_) { cueReq_ = false; if (rlen_ > 0 && cueState_ == 0) { cueState_ = 1; cueLeft_ = cueFade; } }

        if (s.loopOn)
        {
            const bool active = state_ == LOOP && ! loopExiting_;
            if (state_ != GRAB && (! active || loopBeatsAct_ != s.loopBeats)) engageLoopDeck (s);
        }
        else
        {
            loopFail_ = false;
            if (state_ == LOOP && ! loopExiting_) { loopExiting_ = true; xfTarget_ = 0; }
        }
        if (spinReq_)
        {
            spinReq_ = false;
            if (state_ != LOOP && rlen_ > 0)
            {
                if (state_ == LIVE && xf_ <= 0.f) head_ = motorPos_;
                p1_ = head_; state_ = SPIN; spinVel_ = -clampd (s.spinSpeed, 1.0, 16.0); xfTarget_ = 1;
            }
        }
        switch (state_)
        {
            case LIVE:
                if (wantGrab) { head_ = p1_ = anchorR_ = (xf_ <= 0.f) ? motorPos_ : head_; anchorP_ = engageP; state_ = GRAB; xfTarget_ = 1; }
                break;
            case GRAB:   if (! wantGrab) releaseDeck (s); break;
            case SPIN:   if (wantGrab) { p1_ = anchorR_ = head_; anchorP_ = engageP; spinVel_ = 0; state_ = GRAB; } break;
            case RETURN: if (wantGrab) { p1_ = anchorR_ = head_; anchorP_ = engageP; state_ = GRAB; } break;
            case LOOP:
                if (wantGrab && moved && ! loopExiting_)
                {
                    head_ = p1_ = anchorR_ = (double) (loopStart_ + loopPos_); anchorP_ = engageP;
                    state_ = GRAB; xfTarget_ = 1; xf_ = 1; handTookLoop_ = true;
                }
                break;
            case PLAY:   break;                                                   // (live source only)
        }

        const double tauPole = clampd (s.inertiaMs, 2.0, 100.0) * 0.001 * 0.5;
        const double a = 1.0 - std::exp (-1.0 / (tauPole * sr));
        const double aRet = 1.0 - std::exp (-1.0 / (0.06 * sr));                 // the record picks up speed under the motor
        const double accUp = 1.0 / (clampd (s.startSec, 0.05, 5.0) * sr);
        const double accDn = 1.0 / (clampd (s.stopSec, 0.05, 10.0) * sr);
        const double spinDecay = std::exp (-1.0 / ((clampd (s.spinSec, 0.1, 6.0) / 4.6) * sr));
        const double throwFrames = clampd (s.throwSec, 0.1, 4.0) * sr;
        const float xfStep = (float) (1.0 / (0.005 * sr));
        const float cutStep = (float) (1.0 / (clampd (s.cutMs, 0.2, 50.0) * 0.001 * sr));
        const float gain = std::pow (10.f, clampf (s.outDb, -60.f, 24.f) / 20.f);
        const double vmax = 12.0;
        const double bpf = clampd (s.bpm, 40.0, 240.0) / 60.0 / sr;
        const double beat0 = s.ppqValid ? s.ppq : internalBeats_;
        const double stepBeats = clampd (s.tStepBeats, 0.05, 4.0);
        const double duty = clampd ((double) s.tDuty, 0.05, 1.0);
        curT_ = s.motorOn ? clampd (s.speed, 0.05, 4.0) * (s.reverse ? -1.0 : 1.0) : 0.0;

        for (int i = 0; i < n; ++i)
        {
            const float l = inL[i], r = inR[i];
            { const uint32_t wi = (uint32_t) (wAbs_ & mask_); bl[wi] = l; br[wi] = r; ++wAbs_; }    // keep the live history going

            // the motor; while a hand (vinyl) or a loop holds the record, the needle stays where it is
            stepMotor (accUp, accDn);
            const bool held = (state_ == LOOP && ! loopExiting_) || (vinyl && (state_ == GRAB || state_ == SPIN || state_ == RETURN));
            if (! held) motorPos_ = clampd (motorPos_ + motorVel_, lo, hi);

            double v = motorVel_;
            switch (state_)
            {
                case GRAB:
                {
                    const double t = clampd (anchorR_ + (double) (p - anchorP_) * throwFrames, lo, hi);
                    p1_ += (t - p1_) * a;
                    double d = (p1_ - head_) * a;
                    d = clampd (d, -vmax, vmax);
                    head_ += d; v = d;
                    break;
                }
                case SPIN:
                    v = spinVel_; head_ += v; spinVel_ *= spinDecay;
                    if (std::fabs (spinVel_) < 0.04 || head_ <= lo) { head_ = clampd (head_, lo, hi); spinVel_ = 0; vel_ = v; releaseDeck (s); }
                    break;
                case RETURN:
                    vRet_ += (motorVel_ - vRet_) * aRet; v = vRet_; head_ += v;
                    if (std::fabs (vRet_ - motorVel_) < 0.01 || head_ >= hi) { motorPos_ = clampd (head_, lo, hi); state_ = LIVE; xf_ = xfTarget_ = 0; v = motorVel_; }
                    break;
                case LIVE:
                    if (xf_ > 0.f) head_ += vel_; else head_ = motorPos_;
                    break;
                case LOOP:
                    v = 1.0;
                    break;
                case PLAY:
                    break;
            }
            if (state_ != LOOP) head_ = clampd (head_, lo, hi);
            vel_ = v;

            if (xf_ < xfTarget_) xf_ = std::fmin (xf_ + xfStep, xfTarget_); else if (xf_ > xfTarget_) xf_ = std::fmax (xf_ - xfStep, xfTarget_);
            if (state_ == LOOP && loopExiting_ && xf_ <= 0.f) { state_ = LIVE; loopExiting_ = false; head_ = p1_ = motorPos_; }

            float dL = 0.f, dR = 0.f;
            if (rlen_ > 0)
            {
                if (xf_ < 1.f)                                                    // the record under the motor
                {
                    const float g = speedGain (motorVel_);
                    if (g > 0.f) { dL = hermiteRec (rl_, motorPos_) * g; dR = hermiteRec (rr_, motorPos_) * g; }
                }
                if (xf_ > 0.f)
                {
                    float pl, pr;
                    if (state_ == LOOP) loopSampleRec (pl, pr);
                    else { const float g = speedGain (v); pl = hermiteRec (rl_, head_) * g; pr = hermiteRec (rr_, head_) * g; }
                    if (state_ == LOOP && xf_ < 1.f) { const float a = sfade (1.f - xf_), b = 1.f - a; dL = dL * a + pl * b; dR = dR * a + pr * b; }
                    else if (state_ == LOOP) { dL = pl; dR = pr; }
                    else { dL = dL * (1.f - xf_) + pl * xf_; dR = dR * (1.f - xf_) + pr * xf_; }
                }
            }

            // CUE: a 3 ms fade out, drop the needle at the start, fade back in
            if (cueState_ != 0)
            {
                float g;
                if (cueState_ == 1)
                {
                    g = (float) cueLeft_ / (float) cueFade;
                    if (--cueLeft_ <= 0)
                    {
                        motorPos_ = 0;
                        if (state_ != LOOP) { state_ = LIVE; xf_ = xfTarget_ = 0; head_ = p1_ = 0; spinVel_ = 0; idle_ = 1e9; }
                        cueState_ = 2; cueLeft_ = 0;
                    }
                }
                else
                {
                    g = (float) cueLeft_ / (float) cueFade;
                    if (++cueLeft_ >= cueFade) cueState_ = 0;
                }
                dL *= g; dR *= g;
            }

            const bool closed = s.faderClosed != (chopLeft_ > 0);
            if (chopLeft_ > 0) --chopLeft_;
            const float ct = closed ? 0.f : 1.f;
            if (cut_ < ct) cut_ = std::fmin (cut_ + cutStep, ct); else if (cut_ > ct) cut_ = std::fmax (cut_ - cutStep, ct);
            {
                float tt = 1.f;
                if (s.tOn)
                {
                    const double sp = (beat0 + (double) i * bpf) / stepBeats, fl = std::floor (sp);
                    const int si = (int) (((int64_t) fl % 16 + 16) % 16);
                    tt = (((s.tMask >> si) & 1u) != 0 && (sp - fl) < duty) ? 1.f : 0.f;
                }
                if (tg_ < tt) tg_ = std::fmin (tg_ + cutStep, tt); else if (tg_ > tt) tg_ = std::fmax (tg_ - cutStep, tt);
            }
            // the fader, the transformer and the output level act on the record; the incoming beat stays as it is
            motion_ += (state_ == LIVE) ? motorVel_ : v;
            const float dg = cut_ * tg_ * gain;
            outL[i] = (s.thru ? l : 0.f) + dL * dg;
            outR[i] = (s.thru ? r : 0.f) + dR * dg;
        }
        lastPlatter_ = p;
        internalBeats_ = beat0 + (double) n * bpf;
    }

    // ================================================================ live source helpers
    bool engageLoop (const Settings& s)
    {
        const double bpm = clampd (s.bpm, 40.0, 240.0);
        const double beats = clampd (s.loopBeats, 0.0625, kMaxLoopBeats);
        const double fpb = 60.0 / bpm * sr_;                                      // frames per beat
        const int64_t L = (int64_t) std::llround (beats * fpb);
        // A running loop keeps the history frozen: re-sizing it (a roll from 1/8 to 1/16, LOOP 1/2, x2) cuts the new loop from
        // the same frozen audio. A new loop freezes it now, and remembers which beat the frozen write head sits on.
        const bool running = state_ == LOOP && ! loopExiting_;
        const double nowBeat = s.ppqValid ? s.ppq : internalBeats_;
        if (! running) { freezeBeat_ = nowBeat; gridOrigin_ = s.ppqValid ? 0.0 : nowBeat; }
        // the loop is the most recent stretch of the frozen audio that sits on its own grid (on the MPC's bars when it plays,
        // else on the moment you pressed); it plays at the phase the grid says now, so beats land on beats
        const double rel = freezeBeat_ - gridOrigin_;
        const double endBeat = gridOrigin_ + std::floor (rel / beats + 1e-9) * beats, startBeat = endBeat - beats;
        const int64_t back = (int64_t) std::llround ((freezeBeat_ - startBeat) * fpb);   // frames from the loop start to the frozen head
        double ph = (nowBeat - gridOrigin_) - std::floor ((nowBeat - gridOrigin_) / beats + 1e-9) * beats;
        int64_t pos = (int64_t) std::llround (ph * fpb); if (pos < 0 || pos >= L) pos = 0;
        int64_t xf = (int64_t) std::llround (clampd ((double) L / 8.0, 0.0015 * sr_, 0.006 * sr_)); if (xf < 16) xf = 16;
        if (xf > L / 2) xf = L / 2;
        loopNeedSec_ = (double) back / sr_;
        const int64_t cap = (int64_t) size_ - 16 - xf - 8;                              // the most the history can ever hold
        const int64_t have = (wAbs_ < (int64_t) size_ - 16 ? wAbs_ : (int64_t) size_ - 16) - xf - 8;     // history we can loop
        const bool tooLong = L < 64 || back > cap, notYet = back > have;
        if (tooLong || notYet)
        {
            loopFail_ = true; loopFailLong_ = tooLong;
            if (running) loopBeatsAct_ = s.loopBeats;        // keep the loop that's playing; don't retry every block
            return false;
        }
        if (running && xf_ >= 1.f)                                                      // re-size: crossfade from the old loop
        {
            oStart_ = loopStart_; oLen_ = loopLen_; oPos_ = loopPos_; oXf_ = loopXf_;
            swLen_ = (int64_t) (0.006 * sr_); if (swLen_ < 16) swLen_ = 16; swLeft_ = swLen_;
        }
        loopFail_ = false; loopFailLong_ = false; loopLen_ = L; loopStart_ = wAbs_ - back; loopPos_ = pos; loopXf_ = xf;
        loopBeatsAct_ = s.loopBeats; loopExiting_ = false; state_ = LOOP; xfTarget_ = 1; spinVel_ = 0;
        return true;
    }
    // S-curve crossfade gain (sin^2): starts and ends flat, and the two sides always add up to 1 (no level bump when they sound alike)
    static inline float sfade (float x) { const float q = std::sin (clampf (x, 0.f, 1.f) * 1.5707963f); return q * q; }
    // One loop voice: read, crossfade into the audio before the loop start over the last xfn frames (S-curve), advance.
    template <class R> static inline void loopVoice (int64_t start, int64_t len, int64_t& pos, int64_t xfn, R rd, float& pl, float& pr)
    {
        const int64_t idx = start + pos;
        rd (idx, pl, pr);
        const int64_t tail = len - pos;                            // frames left before the wrap (>= 1)
        if (tail <= xfn)
        {
            const float g = (float) (xfn - tail + 1) / (float) xfn;
            float ql, qr; rd (idx - len, ql, qr);
            const float a = sfade (1.f - g), b = 1.f - a;
            pl = pl * a + ql * b; pr = pr * a + qr * b;
        }
        if (++pos >= len) pos = 0;
    }
    // the loop's output: the current voice, and while a re-size is fading, the old one under it
    template <class R> inline void loopOut (R rd, float& pl, float& pr)
    {
        loopVoice (loopStart_, loopLen_, loopPos_, loopXf_, rd, pl, pr);
        if (swLeft_ > 0)
        {
            float ql, qr; loopVoice (oStart_, oLen_, oPos_, oXf_, rd, ql, qr);
            const float g = 1.f - (float) swLeft_ / (float) swLen_;
            const float a = sfade (1.f - g), b = 1.f - a;
            pl = ql * a + pl * b; pr = qr * a + pr * b;
            --swLeft_;
        }
    }
    inline void loopSample (const float* bl, const float* br, float& pl, float& pr)
    {
        const uint64_t m = mask_;
        loopOut ([&] (int64_t i, float& a, float& b) { const uint64_t j = (uint64_t) i & m; a = bl[j]; b = br[j]; }, pl, pr);
    }
    // the motor: constant torque towards curT_ (speeds up with accUp, slows or reverses with accDn)
    inline void stepMotor (double accUp, double accDn)
    {
        const double T = curT_;
        if (motorVel_ == T) return;
        const bool speedingUp = std::fabs (T) > std::fabs (motorVel_) && T * motorVel_ >= 0.0;
        const double a = speedingUp ? accUp : accDn;
        if (motorVel_ < T) motorVel_ = std::fmin (motorVel_ + a, T); else motorVel_ = std::fmax (motorVel_ - a, T);
    }
    void release (const Settings& s)
    {
        if (curT_ != 1.0 || motorVel_ != 1.0) { state_ = PLAY; recVel_ = vel_; xfTarget_ = 1; return; }   // the motor takes the record
        if (s.returnMode == 1) { state_ = RETURN; vRet_ = 0; }
        else { state_ = LIVE; xfTarget_ = 0; }          // slip: back to live; the head keeps playing for the 5 ms crossfade
    }
    void endSpin (const Settings& s) { spinVel_ = 0; release (s); }

    inline float hermite (const float* b, int64_t i, float f) const
    {
        const uint64_t m = mask_;
        const float y0 = b[(uint64_t) (i - 1) & m], y1 = b[(uint64_t) i & m], y2 = b[(uint64_t) (i + 1) & m], y3 = b[(uint64_t) (i + 2) & m];
        const float c1 = 0.5f * (y2 - y0);
        const float c2 = y0 - 2.5f * y1 + 2.f * y2 - 0.5f * y3;
        const float c3 = 0.5f * (y3 - y0) + 1.5f * (y1 - y2);
        return ((c3 * f + c2) * f + c1) * f + y1;
    }

    float inPeak_ = 0.f;
    float* mem_ = nullptr;
    uint32_t size_ = 0, mask_ = 0;
    double sr_ = 44100.0;
    int64_t wAbs_ = 0;                  // frames written so far; newest sample is wAbs_ - 1
    double head_ = 0, p1_ = 0, anchorR_ = 0;
    float anchorP_ = 0.5f, lastPlatter_ = 0.5f, xf_ = 0, xfTarget_ = 0, cut_ = 1;
    double idle_ = 1e9, vel_ = 0, spinVel_ = 0, vRet_ = 0;
    int64_t chopLeft_ = 0;
    State state_ = LIVE;
    bool spinReq_ = false, chopReq_ = false;
    int64_t loopStart_ = 0, loopLen_ = 0, loopPos_ = 0, loopXf_ = 0;
    int64_t oStart_ = 0, oLen_ = 1, oPos_ = 0, oXf_ = 16, swLeft_ = 0, swLen_ = 1;      // the old loop, fading out after a re-size
    double freezeBeat_ = 0, gridOrigin_ = 0;                                            // the beat at the frozen head; the loop grid
    bool loopExiting_ = false, loopFail_ = false;
    double loopBeatsAct_ = -1, internalBeats_ = 0;
    float tg_ = 1.f;
    // SAMPLE source
    const float* rl_ = nullptr; const float* rr_ = nullptr; int64_t rlen_ = 0;
    double motorPos_ = 0, motorVel_ = 1, recVel_ = 1, curT_ = 1, motion_ = 0;
    double ringSec_ = 8.0;
    PitchShifter shifter_;
    bool handTookLoop_ = false;
    bool loopFailLong_ = false; double loopNeedSec_ = 0;
public:
    static constexpr double kMaxLoopBeats = 256.0;      // 64 bars of 4/4
private:
    bool deckMode_ = false, cueReq_ = false;
    int cueState_ = 0, cueLeft_ = 0;
};
} // namespace ds
